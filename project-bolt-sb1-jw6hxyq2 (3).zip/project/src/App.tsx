import React, { useState } from 'react';
import LoginPage from './components/LoginPage';
import AdminDashboard from './components/AdminDashboard';
import PoliceDashboard from './components/PoliceDashboard';
import CitizenDashboard from './components/CitizenDashboard';
import { User } from './types';

function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const handleLogout = () => {
    setCurrentUser(null);
  };

  if (!currentUser) {
    return <LoginPage onLogin={setCurrentUser} />;
  }

  switch (currentUser.role) {
    case 'admin':
      return <AdminDashboard user={currentUser} onLogout={handleLogout} />;
    case 'police':
      return <PoliceDashboard user={currentUser} onLogout={handleLogout} />;
    case 'citizen':
      return <CitizenDashboard user={currentUser} onLogout={handleLogout} />;
    default:
      return <LoginPage onLogin={setCurrentUser} />;
  }
}

export default App;