export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'police' | 'citizen';
  badge?: string;
  department?: string;
  createdAt: string;
  isActive: boolean;
}

export interface Citizen {
  id: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  nationalId: string;
  phone: string;
  address: string;
  email: string;
  profession: string;
  emergencyContact: string;
  emergencyPhone: string;
  registrationDate: string;
  isActive: boolean;
  photo?: string;
}

export interface Vehicle {
  id: string;
  ownerId: string;
  ownerName: string;
  make: string;
  model: string;
  year: number;
  licensePlate: string;
  color: string;
  chassisNumber: string;
  engineNumber: string;
  registrationDate: string;
  insuranceNumber: string;
  insuranceExpiry: string;
  technicalControlExpiry: string;
  isActive: boolean;
}

export interface Violation {
  id: string;
  citizenId: string;
  citizenName: string;
  vehicleId: string;
  vehiclePlate: string;
  officerId: string;
  officerName: string;
  type: string;
  description: string;
  fine: number;
  date: string;
  location: string;
  status: 'pending' | 'paid' | 'contested' | 'cancelled';
  paymentDate?: string;
  contestReason?: string;
  evidence?: string[];
}

export interface SearchNotice {
  id: string;
  type: 'person' | 'vehicle';
  title: string;
  description: string;
  targetDetails: {
    name?: string;
    nationalId?: string;
    licensePlate?: string;
    make?: string;
    model?: string;
    color?: string;
    lastSeenLocation?: string;
    physicalDescription?: string;
  };
  issuedBy: string;
  issueDate: string;
  status: 'active' | 'resolved' | 'cancelled';
  priority: 'low' | 'medium' | 'high';
  reward?: number;
  contactInfo: string;
}

export interface Report {
  id: string;
  citizenId: string;
  citizenName: string;
  type: 'theft' | 'accident' | 'suspicious' | 'other';
  title: string;
  description: string;
  location: string;
  date: string;
  status: 'pending' | 'investigating' | 'resolved' | 'closed';
  assignedOfficer?: string;
  evidence?: string[];
  priority: 'low' | 'medium' | 'high';
}

export interface Payment {
  id: string;
  violationId: string;
  citizenId: string;
  amount: number;
  paymentMethod: 'cash' | 'mobile_money' | 'bank_transfer';
  paymentDate: string;
  receiptNumber: string;
  status: 'completed' | 'pending' | 'failed';
}