import React, { useState } from 'react';
import { Shield, FileX, AlertTriangle, Search, Plus, Users, Car, MapPin, Calendar, Phone, Eye, Edit, Filter, Download } from 'lucide-react';
import { User, Citizen, Vehicle, Violation, SearchNotice } from '../types';
import Header from './shared/Header';
import StatsCard from './shared/StatsCard';

interface PoliceDashboardProps {
  user: User;
  onLogout: () => void;
}

const PoliceDashboard: React.FC<PoliceDashboardProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('violations');
  const [showViolationForm, setShowViolationForm] = useState(false);
  const [showNoticeForm, setShowNoticeForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchType, setSearchType] = useState('citizen');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [showCitizenForm, setShowCitizenForm] = useState(false);

  const stats = [
    { title: 'Mes Contraventions', value: '47', change: '+3%', icon: FileX, color: 'orange' },
    { title: 'Recherches Actives', value: '12', change: '+1%', icon: AlertTriangle, color: 'red' },
    { title: 'Citoyens Consultés', value: '156', change: '+8%', icon: Users, color: 'blue' },
    { title: 'Véhicules Contrôlés', value: '89', change: '+5%', icon: Car, color: 'green' },
  ];

  const violations: Violation[] = [
    {
      id: '1',
      citizenId: '1',
      citizenName: 'Thomas Sankara',
      vehicleId: '1',
      vehiclePlate: 'BF-001-AB',
      officerId: user.id,
      officerName: user.name,
      type: 'Excès de vitesse',
      description: 'Vitesse constatée: 80 km/h en zone 50 km/h',
      fine: 25000,
      date: '2024-01-20',
      location: 'Avenue Kwame Nkrumah',
      status: 'pending'
    },
    {
      id: '2',
      citizenId: '2',
      citizenName: 'Marie Compaoré',
      vehicleId: '2',
      vehiclePlate: 'BF-002-CD',
      officerId: user.id,
      officerName: user.name,
      type: 'Stationnement interdit',
      description: 'Stationnement sur place handicapé',
      fine: 15000,
      date: '2024-01-18',
      location: 'Centre-ville',
      status: 'paid',
      paymentDate: '2024-01-25'
    },
    {
      id: '3',
      citizenId: '3',
      citizenName: 'Jean Ouédraogo',
      vehicleId: '3',
      vehiclePlate: 'BF-003-EF',
      officerId: user.id,
      officerName: user.name,
      type: 'Feu rouge grillé',
      description: 'Non-respect du feu rouge à l\'intersection',
      fine: 30000,
      date: '2024-01-15',
      location: 'Carrefour Wemtenga',
      status: 'contested',
      contestReason: 'Feu défaillant au moment des faits'
    },
  ];

  const searchNotices: SearchNotice[] = [
    {
      id: '1',
      type: 'person',
      title: 'Vol de véhicule - Suspect recherché',
      description: 'Individu suspecté de vol de véhicule, armé et dangereux. Approcher avec précaution.',
      targetDetails: {
        name: 'Inconnu',
        physicalDescription: 'Homme, 25-30 ans, 1m75, cicatrice joue droite, cheveux courts',
        lastSeenLocation: 'Marché central, Ouagadougou'
      },
      issuedBy: 'Commissaire Central',
      issueDate: '2024-01-22',
      status: 'active',
      priority: 'high',
      reward: 100000,
      contactInfo: '+226 70 00 00 00'
    },
    {
      id: '2',
      type: 'vehicle',
      title: 'Véhicule volé - Délit de fuite',
      description: 'Véhicule impliqué dans un délit de fuite avec blessés graves. Recherche prioritaire.',
      targetDetails: {
        licensePlate: 'BF-999-XY',
        make: 'Nissan',
        model: 'Sentra',
        color: 'Rouge',
        lastSeenLocation: 'Route de Koudougou, sortie ville'
      },
      issuedBy: 'Brigade Routière',
      issueDate: '2024-01-21',
      status: 'active',
      priority: 'medium',
      contactInfo: '+226 70 00 00 01'
    },
  ];

  // Données de démonstration pour la recherche
  const mockCitizens: Citizen[] = [
    {
      id: '1',
      firstName: 'Thomas',
      lastName: 'Sankara',
      nationalId: 'BF123456789',
      phone: '+226 70 12 34 56',
      email: 'thomas.sankara@email.com',
      dateOfBirth: '1985-03-15',
      address: 'Secteur 15, Ouagadougou',
      profession: 'Enseignant',
      emergencyContact: 'Marie Sankara',
      emergencyPhone: '+226 71 23 45 67',
      registrationDate: '2024-01-15',
      isActive: true
    },
    {
      id: '2',
      firstName: 'Marie',
      lastName: 'Compaoré',
      nationalId: 'BF987654321',
      phone: '+226 71 98 76 54',
      email: 'marie.compaore@email.com',
      dateOfBirth: '1990-07-22',
      address: 'Secteur 30, Ouagadougou',
      profession: 'Commerçante',
      emergencyContact: 'Jean Compaoré',
      emergencyPhone: '+226 72 34 56 78',
      registrationDate: '2024-01-10',
      isActive: true
    },
  ];

  const mockVehicles: Vehicle[] = [
    {
      id: '1',
      ownerId: '1',
      ownerName: 'Thomas Sankara',
      licensePlate: 'BF-001-AB',
      make: 'Toyota',
      model: 'Corolla',
      year: 2020,
      color: 'Blanc',
      chassisNumber: 'JT123456789',
      engineNumber: 'EN123456789',
      registrationDate: '2024-01-15',
      insuranceNumber: 'ASS123456',
      insuranceExpiry: '2024-12-31',
      technicalControlExpiry: '2024-06-30',
      isActive: true
    },
    {
      id: '2',
      ownerId: '2',
      ownerName: 'Marie Compaoré',
      licensePlate: 'BF-002-CD',
      make: 'Honda',
      model: 'Civic',
      year: 2019,
      color: 'Noir',
      chassisNumber: 'HC987654321',
      engineNumber: 'EN987654321',
      registrationDate: '2024-01-10',
      insuranceNumber: 'ASS987654',
      insuranceExpiry: '2024-11-15',
      technicalControlExpiry: '2024-05-20',
      isActive: true
    },
  ];

  const handleSearch = () => {
    if (!searchTerm.trim()) return;

    let results: any[] = [];
    
    if (searchType === 'citizen') {
      results = mockCitizens.filter(citizen => 
        citizen.nationalId.toLowerCase().includes(searchTerm.toLowerCase()) ||
        citizen.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        citizen.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        citizen.phone.includes(searchTerm)
      );
    } else if (searchType === 'vehicle') {
      results = mockVehicles.filter(vehicle =>
        vehicle.licensePlate.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vehicle.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
        vehicle.model.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    
    setSearchResults(results);
  };

  const ViolationForm = () => {
    const [formData, setFormData] = useState({
      citizenId: '',
      vehiclePlate: '',
      type: '',
      description: '',
      location: '',
      fine: ''
    });

    const violationTypes = [
      { value: 'speeding', label: 'Excès de vitesse', fine: 25000 },
      { value: 'parking', label: 'Stationnement interdit', fine: 15000 },
      { value: 'red_light', label: 'Feu rouge grillé', fine: 30000 },
      { value: 'phone', label: 'Téléphone au volant', fine: 20000 },
      { value: 'seatbelt', label: 'Ceinture de sécurité', fine: 10000 },
      { value: 'documents', label: 'Défaut de documents', fine: 35000 },
      { value: 'other', label: 'Autre', fine: 0 }
    ];

    const handleTypeChange = (type: string) => {
      const selectedType = violationTypes.find(vt => vt.value === type);
      setFormData(prev => ({
        ...prev,
        type: selectedType?.label || '',
        fine: selectedType?.fine.toString() || ''
      }));
    };

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900">Nouvelle Contravention</h3>
            <p className="text-sm text-gray-600 mt-1">Remplissez tous les champs obligatoires</p>
          </div>
          
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">CNI du Citoyen *</label>
                <input
                  type="text"
                  value={formData.citizenId}
                  onChange={(e) => setFormData(prev => ({ ...prev, citizenId: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="BF123456789"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Plaque d'immatriculation *</label>
                <input
                  type="text"
                  value={formData.vehiclePlate}
                  onChange={(e) => setFormData(prev => ({ ...prev, vehiclePlate: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="BF-001-AB"
                  required
                />
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type d'infraction *</label>
              <select 
                onChange={(e) => handleTypeChange(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                <option value="">Sélectionner une infraction</option>
                {violationTypes.map(type => (
                  <option key={type.value} value={type.value}>
                    {type.label} {type.fine > 0 && `(${type.fine.toLocaleString()} FCFA)`}
                  </option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description détaillée *</label>
              <textarea
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Description précise de l'infraction constatée..."
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Lieu précis *</label>
                <input
                  type="text"
                  value={formData.location}
                  onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Avenue Kwame Nkrumah, Ouagadougou"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Montant de l'amende (FCFA) *</label>
                <input
                  type="number"
                  value={formData.fine}
                  onChange={(e) => setFormData(prev => ({ ...prev, fine: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="25000"
                  required
                />
              </div>
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800 text-sm">
                <strong>Information:</strong> Cette contravention sera automatiquement enregistrée dans le système 
                et le citoyen sera notifié par SMS si un numéro de téléphone est disponible.
              </p>
            </div>
          </div>
          
          <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
            <button
              onClick={() => setShowViolationForm(false)}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <button className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors">
              Enregistrer la contravention
            </button>
          </div>
        </div>
      </div>
    );
  };

  const NoticeForm = () => {
    const [formData, setFormData] = useState({
      type: 'person',
      title: '',
      description: '',
      priority: 'medium',
      targetName: '',
      targetId: '',
      physicalDescription: '',
      vehiclePlate: '',
      vehicleMake: '',
      vehicleModel: '',
      vehicleColor: '',
      lastLocation: '',
      reward: '',
      contactInfo: user.phone || '+226 70 00 00 00'
    });

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900">Nouvel Avis de Recherche</h3>
            <p className="text-sm text-gray-600 mt-1">Créer un avis de recherche pour diffusion</p>
          </div>
          
          <div className="p-6 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Type de recherche *</label>
                <select 
                  value={formData.type}
                  onChange={(e) => setFormData(prev => ({ ...prev, type: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="person">Personne</option>
                  <option value="vehicle">Véhicule</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Priorité *</label>
                <select 
                  value={formData.priority}
                  onChange={(e) => setFormData(prev => ({ ...prev, priority: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="low">Faible</option>
                  <option value="medium">Moyenne</option>
                  <option value="high">Haute</option>
                </select>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Titre de l'avis *</label>
              <input
                type="text"
                value={formData.title}
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Vol de véhicule - Suspect recherché"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description détaillée *</label>
              <textarea
                rows={4}
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Description complète de la situation et des éléments recherchés..."
                required
              />
            </div>

            {formData.type === 'person' ? (
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Informations sur la personne</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Nom (si connu)</label>
                    <input
                      type="text"
                      value={formData.targetName}
                      onChange={(e) => setFormData(prev => ({ ...prev, targetName: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Nom de la personne"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">CNI (si connue)</label>
                    <input
                      type="text"
                      value={formData.targetId}
                      onChange={(e) => setFormData(prev => ({ ...prev, targetId: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="BF123456789"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Description physique</label>
                  <textarea
                    rows={3}
                    value={formData.physicalDescription}
                    onChange={(e) => setFormData(prev => ({ ...prev, physicalDescription: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Âge, taille, signes distinctifs, vêtements..."
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <h4 className="font-medium text-gray-900">Informations sur le véhicule</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Plaque d'immatriculation</label>
                    <input
                      type="text"
                      value={formData.vehiclePlate}
                      onChange={(e) => setFormData(prev => ({ ...prev, vehiclePlate: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="BF-999-XY"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Couleur</label>
                    <input
                      type="text"
                      value={formData.vehicleColor}
                      onChange={(e) => setFormData(prev => ({ ...prev, vehicleColor: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Rouge, Blanc, etc."
                    />
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Marque</label>
                    <input
                      type="text"
                      value={formData.vehicleMake}
                      onChange={(e) => setFormData(prev => ({ ...prev, vehicleMake: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Toyota, Honda, etc."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Modèle</label>
                    <input
                      type="text"
                      value={formData.vehicleModel}
                      onChange={(e) => setFormData(prev => ({ ...prev, vehicleModel: e.target.value }))}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      placeholder="Corolla, Civic, etc."
                    />
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Dernière localisation connue</label>
                <input
                  type="text"
                  value={formData.lastLocation}
                  onChange={(e) => setFormData(prev => ({ ...prev, lastLocation: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Lieu, quartier, ville..."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Récompense (FCFA)</label>
                <input
                  type="number"
                  value={formData.reward}
                  onChange={(e) => setFormData(prev => ({ ...prev, reward: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="100000"
                />
              </div>
            </div>

            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800 text-sm">
                <strong>Important:</strong> Cet avis sera diffusé à toutes les unités. 
                Assurez-vous que toutes les informations sont exactes et vérifiées.
              </p>
            </div>
          </div>
          
          <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
            <button
              onClick={() => setShowNoticeForm(false)}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <button className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors">
              Publier l'avis
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderViolations = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Mes Contraventions</h2>
        <div className="flex space-x-3">
          <button className="flex items-center px-4 py-2 text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg transition-colors">
            <Download className="w-4 h-4 mr-2" />
            Exporter
          </button>
          <button
            onClick={() => setShowViolationForm(true)}
            className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            <Plus className="w-5 h-5 mr-2" />
            Nouvelle Contravention
          </button>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Citoyen</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Véhicule</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Infraction</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amende</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {violations.map((violation) => (
                <tr key={violation.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.citizenName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">{violation.vehiclePlate}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{violation.type}</div>
                    <div className="text-sm text-gray-500">{violation.location}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.fine.toLocaleString()} FCFA</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      violation.status === 'paid' ? 'bg-green-100 text-green-800' :
                      violation.status === 'contested' ? 'bg-red-100 text-red-800' :
                      violation.status === 'cancelled' ? 'bg-gray-100 text-gray-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {violation.status === 'paid' ? 'Payée' :
                       violation.status === 'contested' ? 'Contestée' :
                       violation.status === 'cancelled' ? 'Annulée' : 'En attente'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        <Edit className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderNotices = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Avis de Recherche</h2>
        <button
          onClick={() => setShowNoticeForm(true)}
          className="flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
        >
          <Plus className="w-5 h-5 mr-2" />
          Nouvel Avis
        </button>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {searchNotices.map((notice) => (
          <div key={notice.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <AlertTriangle className="w-6 h-6 text-red-600 mr-3" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{notice.title}</h3>
                  <p className="text-sm text-gray-500">{notice.type === 'person' ? 'Personne' : 'Véhicule'} recherché(e)</p>
                </div>
              </div>
              <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                notice.priority === 'high' ? 'bg-red-100 text-red-800' :
                notice.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {notice.priority === 'high' ? 'Haute' : notice.priority === 'medium' ? 'Moyenne' : 'Faible'}
              </span>
            </div>
            
            <p className="text-gray-700 mb-4">{notice.description}</p>
            
            <div className="space-y-2 text-sm text-gray-600 mb-4">
              {notice.type === 'person' ? (
                <>
                  {notice.targetDetails.physicalDescription && (
                    <p><strong>Description:</strong> {notice.targetDetails.physicalDescription}</p>
                  )}
                  {notice.targetDetails.lastSeenLocation && (
                    <p><strong>Dernière localisation:</strong> {notice.targetDetails.lastSeenLocation}</p>
                  )}
                </>
              ) : (
                <>
                  <p><strong>Véhicule:</strong> {notice.targetDetails.make} {notice.targetDetails.model}</p>
                  <p><strong>Plaque:</strong> {notice.targetDetails.licensePlate}</p>
                  <p><strong>Couleur:</strong> {notice.targetDetails.color}</p>
                  {notice.targetDetails.lastSeenLocation && (
                    <p><strong>Dernière localisation:</strong> {notice.targetDetails.lastSeenLocation}</p>
                  )}
                </>
              )}
              {notice.reward && (
                <p><strong>Récompense:</strong> {notice.reward.toLocaleString()} FCFA</p>
              )}
              <p><strong>Contact:</strong> {notice.contactInfo}</p>
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  notice.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {notice.status === 'active' ? 'Actif' : notice.status === 'resolved' ? 'Résolu' : 'Annulé'}
                </span>
                <span className="text-xs text-gray-500 ml-2">Par {notice.issuedBy}</span>
              </div>
              <div className="flex space-x-2">
                <button className="text-blue-600 hover:text-blue-900 text-sm font-medium">
                  Voir détails
                </button>
                <button className="text-green-600 hover:text-green-900 text-sm font-medium">
                  Modifier
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderSearch = () => (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Recherche Citoyens/Véhicules</h2>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type de recherche</label>
              <select 
                value={searchType}
                onChange={(e) => setSearchType(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="citizen">Citoyen</option>
                <option value="vehicle">Véhicule</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Terme de recherche</label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder={searchType === 'citizen' ? 'CNI, nom, téléphone...' : 'Plaque, marque, modèle...'}
              />
            </div>
            <div className="flex items-end">
              <button 
                onClick={handleSearch}
                className="flex items-center px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors w-full justify-center"
              >
                <Search className="w-5 h-5 mr-2" />
                Rechercher
              </button>
            </div>
          </div>
        </div>
      </div>
      
      {searchResults.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Résultats de recherche ({searchResults.length})
          </h3>
          
          {searchType === 'citizen' ? (
            <div className="space-y-4">
              {searchResults.map((citizen: Citizen) => (
                <div key={citizen.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <Users className="w-5 h-5 text-blue-600 mr-2" />
                        <h4 className="text-lg font-semibold text-gray-900">
                          {citizen.firstName} {citizen.lastName}
                        </h4>
                        <span className={`ml-3 px-2 py-1 text-xs font-semibold rounded-full ${
                          citizen.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                        }`}>
                          {citizen.isActive ? 'Actif' : 'Inactif'}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                        <div className="space-y-1">
                          <p><strong>CNI:</strong> {citizen.nationalId}</p>
                          <p><strong>Téléphone:</strong> {citizen.phone}</p>
                          <p><strong>Email:</strong> {citizen.email}</p>
                        </div>
                        <div className="space-y-1">
                          <p><strong>Profession:</strong> {citizen.profession}</p>
                          <p><strong>Date de naissance:</strong> {citizen.dateOfBirth}</p>
                          <p><strong>Enregistré le:</strong> {citizen.registrationDate}</p>
                        </div>
                      </div>
                      
                      <div className="mt-3">
                        <p className="text-sm text-gray-600">
                          <MapPin className="w-4 h-4 inline mr-1" />
                          <strong>Adresse:</strong> {citizen.address}
                        </p>
                      </div>
                      
                      {citizen.emergencyContact && (
                        <div className="mt-3 p-3 bg-yellow-50 rounded-lg">
                          <p className="text-sm text-yellow-800">
                            <Phone className="w-4 h-4 inline mr-1" />
                            <strong>Contact d'urgence:</strong> {citizen.emergencyContact} - {citizen.emergencyPhone}
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex space-x-2 ml-4">
                      <button className="text-blue-600 hover:text-blue-900 p-2">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setShowViolationForm(true)}
                        className="text-orange-600 hover:text-orange-900 p-2"
                        title="Créer une contravention"
                      >
                        <FileX className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {searchResults.map((vehicle: Vehicle) => (
                <div key={vehicle.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <Car className="w-5 h-5 text-green-600 mr-2" />
                        <h4 className="text-lg font-semibold text-gray-900">
                          {vehicle.make} {vehicle.model} ({vehicle.year})
                        </h4>
                        <span className="ml-3 px-2 py-1 text-xs font-semibold bg-blue-100 text-blue-800 rounded-full">
                          {vehicle.licensePlate}
                        </span>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-600">
                        <div className="space-y-1">
                          <p><strong>Propriétaire:</strong> {vehicle.ownerName}</p>
                          <p><strong>Couleur:</strong> {vehicle.color}</p>
                          <p><strong>Châssis:</strong> {vehicle.chassisNumber}</p>
                        </div>
                        <div className="space-y-1">
                          <p><strong>Moteur:</strong> {vehicle.engineNumber}</p>
                          <p><strong>Assurance:</strong> {vehicle.insuranceNumber}</p>
                          <p><strong>Enregistré le:</strong> {vehicle.registrationDate}</p>
                        </div>
                      </div>
                      
                      <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className={`p-3 rounded-lg ${
                          new Date(vehicle.insuranceExpiry) < new Date() ? 'bg-red-50' : 'bg-green-50'
                        }`}>
                          <p className={`text-sm ${
                            new Date(vehicle.insuranceExpiry) < new Date() ? 'text-red-800' : 'text-green-800'
                          }`}>
                            <strong>Assurance expire:</strong> {vehicle.insuranceExpiry}
                            {new Date(vehicle.insuranceExpiry) < new Date() && ' (EXPIRÉE)'}
                          </p>
                        </div>
                        <div className={`p-3 rounded-lg ${
                          new Date(vehicle.technicalControlExpiry) < new Date() ? 'bg-red-50' : 'bg-green-50'
                        }`}>
                          <p className={`text-sm ${
                            new Date(vehicle.technicalControlExpiry) < new Date() ? 'text-red-800' : 'text-green-800'
                          }`}>
                            <strong>Contrôle technique expire:</strong> {vehicle.technicalControlExpiry}
                            {new Date(vehicle.technicalControlExpiry) < new Date() && ' (EXPIRÉ)'}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 ml-4">
                      <button className="text-blue-600 hover:text-blue-900 p-2">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => setShowViolationForm(true)}
                        className="text-orange-600 hover:text-orange-900 p-2"
                        title="Créer une contravention"
                      >
                        <FileX className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
      
      {searchTerm && searchResults.length === 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <div className="text-center py-8">
            <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Aucun résultat trouvé</h3>
            <p className="text-gray-500">
              Aucun {searchType === 'citizen' ? 'citoyen' : 'véhicule'} ne correspond à votre recherche "{searchTerm}".
            </p>
          </div>
        </div>
      )}
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'violations': return renderViolations();
      case 'notices': return renderNotices();
      case 'search': return renderSearch();
      default: return <div>Section en cours de développement</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} onLogout={onLogout} />
      
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Tableau de Bord - Forces de l'Ordre</h1>
          <p className="text-gray-600">Badge: {user.badge} | {user.department}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <StatsCard key={index} {...stat} />
          ))}
        </div>
        
        <div className="mb-6">
          <nav className="flex space-x-1 bg-white rounded-lg p-1 shadow-sm border border-gray-200">
            {[
              { id: 'violations', label: 'Contraventions', icon: FileX },
              { id: 'notices', label: 'Avis de Recherche', icon: AlertTriangle },
              { id: 'search', label: 'Recherche', icon: Search },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  activeTab === item.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <item.icon className="w-4 h-4 mr-2" />
                {item.label}
              </button>
            ))}
          </nav>
        </div>
        
        {renderContent()}
      </div>
      
      {showViolationForm && <ViolationForm />}
      {showNoticeForm && <NoticeForm />}
    </div>
  );
};

export default PoliceDashboard;