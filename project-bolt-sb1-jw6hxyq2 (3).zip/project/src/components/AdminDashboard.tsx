import React, { useState } from 'react';
import { Shield, Users, Car, FileX, AlertTriangle, LogOut, BarChart3, UserCheck, TrendingUp, Activity, Eye, Edit, Trash2, Plus, Search, Filter } from 'lucide-react';
import { User, Citizen, Vehicle, Violation, SearchNotice } from '../types';
import Header from './shared/Header';
import StatsCard from './shared/StatsCard';
import DataTable from './shared/DataTable';

interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showUserForm, setShowUserForm] = useState(false);
  const [showCitizenForm, setShowCitizenForm] = useState(false);
  const [editingUser, setEditingUser] = useState<any>(null);
  const [editingCitizen, setEditingCitizen] = useState<any>(null);

  const stats = [
    { title: 'Citoyens Enregistrés', value: '2,847', change: '+12%', icon: Users, color: 'blue' },
    { title: 'Véhicules', value: '1,923', change: '+8%', icon: Car, color: 'green' },
    { title: 'Contraventions', value: '134', change: '-5%', icon: FileX, color: 'orange' },
    { title: 'Avis de Recherche', value: '7', change: '+2%', icon: AlertTriangle, color: 'red' },
  ];

  const [users, setUsers] = useState([
    {
      id: '1',
      name: 'Administrateur Système',
      email: 'admin@fasopanga.gov.bf',
      role: 'admin',
      createdAt: '2024-01-01',
      isActive: true
    },
    {
      id: '2',
      name: 'Commissaire Ouédraogo',
      email: 'police@fasopanga.gov.bf',
      role: 'police',
      badge: 'FP-001',
      department: 'Police Municipale',
      createdAt: '2024-01-01',
      isActive: true
    },
    {
      id: '3',
      name: 'Agent Kaboré',
      email: 'agent.kabore@fasopanga.gov.bf',
      role: 'police',
      badge: 'FP-002',
      department: 'Brigade Routière',
      createdAt: '2024-01-15',
      isActive: true
    }
  ]);

  const citizens: Citizen[] = [
    { 
      id: '1', 
      firstName: 'Thomas', 
      lastName: 'Sankara', 
      nationalId: 'BF123456789', 
      phone: '+226 70 12 34 56', 
      email: 'thomas.sankara@email.com',
      dateOfBirth: '1985-03-15',
      address: 'Secteur 15, Ouagadougou',
      profession: 'Enseignant',
      emergencyContact: 'Marie Sankara',
      emergencyPhone: '+226 71 23 45 67',
      registrationDate: '2024-01-15',
      isActive: true
    },
    { 
      id: '2', 
      firstName: 'Marie', 
      lastName: 'Compaoré', 
      nationalId: 'BF987654321', 
      phone: '+226 71 98 76 54', 
      email: 'marie.compaore@email.com',
      dateOfBirth: '1990-07-22',
      address: 'Secteur 30, Ouagadougou',
      profession: 'Commerçante',
      emergencyContact: 'Jean Compaoré',
      emergencyPhone: '+226 72 34 56 78',
      registrationDate: '2024-01-10',
      isActive: true
    },
    { 
      id: '3', 
      firstName: 'Jean', 
      lastName: 'Ouédraogo', 
      nationalId: 'BF456789123', 
      phone: '+226 72 45 67 89', 
      email: 'jean.ouedraogo@email.com',
      dateOfBirth: '1982-11-08',
      address: 'Secteur 7, Bobo-Dioulasso',
      profession: 'Mécanicien',
      emergencyContact: 'Fatou Ouédraogo',
      emergencyPhone: '+226 73 45 67 89',
      registrationDate: '2024-01-05',
      isActive: false
    },
  ];

  const vehicles: Vehicle[] = [
    { 
      id: '1', 
      ownerId: '1',
      ownerName: 'Thomas Sankara',
      licensePlate: 'BF-001-AB', 
      make: 'Toyota', 
      model: 'Corolla', 
      year: 2020,
      color: 'Blanc',
      chassisNumber: 'JT123456789',
      engineNumber: 'EN123456789',
      registrationDate: '2024-01-15',
      insuranceNumber: 'ASS123456',
      insuranceExpiry: '2024-12-31',
      technicalControlExpiry: '2024-06-30',
      isActive: true
    },
    { 
      id: '2', 
      ownerId: '2',
      ownerName: 'Marie Compaoré',
      licensePlate: 'BF-002-CD', 
      make: 'Honda', 
      model: 'Civic', 
      year: 2019,
      color: 'Noir',
      chassisNumber: 'HC987654321',
      engineNumber: 'EN987654321',
      registrationDate: '2024-01-10',
      insuranceNumber: 'ASS987654',
      insuranceExpiry: '2024-11-15',
      technicalControlExpiry: '2024-05-20',
      isActive: true
    },
  ];

  const violations: Violation[] = [
    {
      id: '1',
      citizenId: '1',
      citizenName: 'Thomas Sankara',
      vehicleId: '1',
      vehiclePlate: 'BF-001-AB',
      officerId: '2',
      officerName: 'Commissaire Ouédraogo',
      type: 'Excès de vitesse',
      description: 'Vitesse constatée: 80 km/h en zone 50 km/h',
      fine: 25000,
      date: '2024-01-20',
      location: 'Avenue Kwame Nkrumah',
      status: 'pending'
    },
    {
      id: '2',
      citizenId: '2',
      citizenName: 'Marie Compaoré',
      vehicleId: '2',
      vehiclePlate: 'BF-002-CD',
      officerId: '2',
      officerName: 'Commissaire Ouédraogo',
      type: 'Stationnement interdit',
      description: 'Stationnement sur place handicapé',
      fine: 15000,
      date: '2024-01-18',
      location: 'Centre-ville',
      status: 'paid',
      paymentDate: '2024-01-25'
    },
  ];

  const searchNotices: SearchNotice[] = [
    {
      id: '1',
      type: 'person',
      title: 'Vol de véhicule - Suspect recherché',
      description: 'Individu suspecté de vol de véhicule, armé et dangereux',
      targetDetails: {
        name: 'Inconnu',
        physicalDescription: 'Homme, 25-30 ans, 1m75, cicatrice joue droite',
        lastSeenLocation: 'Marché central'
      },
      issuedBy: 'Commissaire Ouédraogo',
      issueDate: '2024-01-22',
      status: 'active',
      priority: 'high',
      reward: 100000,
      contactInfo: '+226 70 00 00 00'
    },
    {
      id: '2',
      type: 'vehicle',
      title: 'Véhicule volé - Délit de fuite',
      description: 'Véhicule impliqué dans un délit de fuite avec blessés',
      targetDetails: {
        licensePlate: 'BF-999-XY',
        make: 'Nissan',
        model: 'Sentra',
        color: 'Rouge',
        lastSeenLocation: 'Route de Koudougou'
      },
      issuedBy: 'Commissaire Ouédraogo',
      issueDate: '2024-01-21',
      status: 'active',
      priority: 'medium',
      contactInfo: '+226 70 00 00 00'
    },
  ];

  const recentActivities = [
    { type: 'citizen', message: 'Nouveau citoyen enregistré: Thomas Sankara', time: '2 heures' },
    { type: 'violation', message: 'Contravention émise par Commissaire Ouédraogo', time: '4 heures' },
    { type: 'notice', message: 'Nouvel avis de recherche publié', time: '6 heures' },
    { type: 'payment', message: 'Paiement reçu pour contravention #002', time: '8 heures' },
    { type: 'vehicle', message: 'Nouveau véhicule enregistré: BF-003-EF', time: '1 jour' },
  ];

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'citizen': return <UserCheck className="w-5 h-5 text-blue-600" />;
      case 'violation': return <FileX className="w-5 h-5 text-orange-600" />;
      case 'notice': return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case 'payment': return <TrendingUp className="w-5 h-5 text-green-600" />;
      case 'vehicle': return <Car className="w-5 h-5 text-purple-600" />;
      default: return <Activity className="w-5 h-5 text-gray-600" />;
    }
  };

  const renderOverview = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Activité Récente</h3>
          <div className="space-y-3">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-center p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                {getActivityIcon(activity.type)}
                <div className="ml-3 flex-1">
                  <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                  <p className="text-xs text-gray-500">Il y a {activity.time}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Statistiques Mensuelles</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-600">Enregistrements Citoyens</span>
                <span className="text-sm font-semibold text-gray-900">85%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-blue-600 h-2 rounded-full" style={{ width: '85%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-600">Contraventions Traitées</span>
                <span className="text-sm font-semibold text-gray-900">72%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-green-600 h-2 rounded-full" style={{ width: '72%' }}></div>
              </div>
            </div>
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-600">Avis Résolus</span>
                <span className="text-sm font-semibold text-gray-900">64%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div className="bg-orange-600 h-2 rounded-full" style={{ width: '64%' }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Alertes et notifications */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Alertes Système</h3>
        <div className="space-y-3">
          <div className="flex items-center p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3" />
            <div>
              <p className="text-sm font-medium text-yellow-800">3 véhicules avec assurance expirée</p>
              <p className="text-xs text-yellow-600">Vérification requise</p>
            </div>
          </div>
          <div className="flex items-center p-3 bg-red-50 border border-red-200 rounded-lg">
            <AlertTriangle className="w-5 h-5 text-red-600 mr-3" />
            <div>
              <p className="text-sm font-medium text-red-800">2 avis de recherche prioritaires actifs</p>
              <p className="text-xs text-red-600">Surveillance renforcée</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderCitizens = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Gestion des Citoyens</h2>
        <div className="flex space-x-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher un citoyen..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="all">Tous les statuts</option>
            <option value="active">Actifs</option>
            <option value="inactive">Inactifs</option>
          </select>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Citoyen</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">CNI</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contact</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Profession</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {citizens.map((citizen) => (
                <tr key={citizen.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{citizen.firstName} {citizen.lastName}</div>
                      <div className="text-sm text-gray-500">{citizen.email}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{citizen.nationalId}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{citizen.phone}</div>
                    <div className="text-sm text-gray-500">{citizen.address}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{citizen.profession}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      citizen.isActive ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {citizen.isActive ? 'Actif' : 'Inactif'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderVehicles = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Gestion des Véhicules</h2>
        <div className="flex space-x-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher par plaque..."
              className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Véhicule</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Propriétaire</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Plaque</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Assurance</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Contrôle Technique</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {vehicles.map((vehicle) => (
                <tr key={vehicle.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900">{vehicle.make} {vehicle.model}</div>
                      <div className="text-sm text-gray-500">{vehicle.year} - {vehicle.color}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{vehicle.ownerName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">{vehicle.licensePlate}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{vehicle.insuranceNumber}</div>
                    <div className={`text-sm ${new Date(vehicle.insuranceExpiry) < new Date() ? 'text-red-600' : 'text-gray-500'}`}>
                      Exp: {vehicle.insuranceExpiry}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className={`text-sm ${new Date(vehicle.technicalControlExpiry) < new Date() ? 'text-red-600' : 'text-gray-500'}`}>
                      Exp: {vehicle.technicalControlExpiry}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        <Edit className="w-4 h-4" />
                      </button>
                      <button className="text-red-600 hover:text-red-900">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderViolations = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Gestion des Contraventions</h2>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Citoyen</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Véhicule</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Infraction</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amende</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {violations.map((violation) => (
                <tr key={violation.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.citizenName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">{violation.vehiclePlate}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{violation.type}</div>
                    <div className="text-sm text-gray-500">{violation.location}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.fine.toLocaleString()} FCFA</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      violation.status === 'paid' ? 'bg-green-100 text-green-800' :
                      violation.status === 'contested' ? 'bg-red-100 text-red-800' :
                      violation.status === 'cancelled' ? 'bg-gray-100 text-gray-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {violation.status === 'paid' ? 'Payée' :
                       violation.status === 'contested' ? 'Contestée' :
                       violation.status === 'cancelled' ? 'Annulée' : 'En attente'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Eye className="w-4 h-4" />
                      </button>
                      <button className="text-green-600 hover:text-green-900">
                        <Edit className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderNotices = () => (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Avis de Recherche</h2>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {searchNotices.map((notice) => (
          <div key={notice.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <AlertTriangle className="w-6 h-6 text-red-600 mr-3" />
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{notice.title}</h3>
                  <p className="text-sm text-gray-500">{notice.type === 'person' ? 'Personne' : 'Véhicule'} recherché(e)</p>
                </div>
              </div>
              <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                notice.priority === 'high' ? 'bg-red-100 text-red-800' :
                notice.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                'bg-gray-100 text-gray-800'
              }`}>
                {notice.priority === 'high' ? 'Haute' : notice.priority === 'medium' ? 'Moyenne' : 'Faible'}
              </span>
            </div>
            
            <p className="text-gray-700 mb-4">{notice.description}</p>
            
            <div className="space-y-2 text-sm text-gray-600 mb-4">
              {notice.type === 'person' ? (
                <>
                  {notice.targetDetails.physicalDescription && (
                    <p><strong>Description:</strong> {notice.targetDetails.physicalDescription}</p>
                  )}
                  {notice.targetDetails.lastSeenLocation && (
                    <p><strong>Dernière localisation:</strong> {notice.targetDetails.lastSeenLocation}</p>
                  )}
                </>
              ) : (
                <>
                  <p><strong>Véhicule:</strong> {notice.targetDetails.make} {notice.targetDetails.model}</p>
                  <p><strong>Plaque:</strong> {notice.targetDetails.licensePlate}</p>
                  <p><strong>Couleur:</strong> {notice.targetDetails.color}</p>
                </>
              )}
              {notice.reward && (
                <p><strong>Récompense:</strong> {notice.reward.toLocaleString()} FCFA</p>
              )}
            </div>
            
            <div className="flex items-center justify-between">
              <div>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  notice.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {notice.status === 'active' ? 'Actif' : notice.status === 'resolved' ? 'Résolu' : 'Annulé'}
                </span>
                <span className="text-xs text-gray-500 ml-2">Par {notice.issuedBy}</span>
              </div>
              <div className="flex space-x-2">
                <button className="text-blue-600 hover:text-blue-900 text-sm font-medium">
                  Voir détails
                </button>
                <button className="text-green-600 hover:text-green-900 text-sm font-medium">
                  Modifier
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'overview': return renderOverview();
      case 'users': return renderUsers();
      case 'citizens': return renderCitizens();
      case 'vehicles': return renderVehicles();
      case 'violations': return renderViolations();
      case 'notices': return renderNotices();
      default: return <div>Section en cours de développement</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} onLogout={onLogout} />
      
      <div className="flex">
        {/* Sidebar */}
        <div className="w-64 bg-white shadow-sm border-r border-gray-200 min-h-screen">
          <div className="p-6">
            <div className="flex items-center mb-8">
              <Shield className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h2 className="text-lg font-bold text-gray-900">FASO PANGA</h2>
                <p className="text-sm text-gray-500">Administration</p>
              </div>
            </div>
            
            <nav className="space-y-2">
              {[
                { id: 'overview', label: 'Vue d\'ensemble', icon: BarChart3 },
                { id: 'users', label: 'Utilisateurs', icon: Users },
                { id: 'citizens', label: 'Citoyens', icon: Users },
                { id: 'vehicles', label: 'Véhicules', icon: Car },
                { id: 'violations', label: 'Contraventions', icon: FileX },
                { id: 'notices', label: 'Avis de Recherche', icon: AlertTriangle },
              ].map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center px-4 py-3 text-left rounded-lg transition-all duration-200 ${
                    activeTab === item.id
                      ? 'bg-blue-50 text-blue-700 border-r-2 border-blue-600'
                      : 'text-gray-600 hover:bg-gray-50'
                  }`}
                >
                  <item.icon className="w-5 h-5 mr-3" />
                  {item.label}
                </button>
              ))}
            </nav>
          </div>
        </div>
        
        {/* Main content */}
        <div className="flex-1 p-8">
          {renderContent()}
        </div>
      </div>
      
      {showUserForm && <UserForm />}
      {showCitizenForm && <CitizenForm />}
    </div>
  );
};

export default AdminDashboard;