import React, { useState } from 'react';
import { User as UserIcon, Car, FileX, Edit, Plus, Save, X, AlertTriangle, CreditCard, Download, Phone, MapPin, Calendar, Eye } from 'lucide-react';
import { User, Citizen, Vehicle, Violation, Report } from '../types';
import Header from './shared/Header';

interface CitizenDashboardProps {
  user: User;
  onLogout: () => void;
}

const CitizenDashboard: React.FC<CitizenDashboardProps> = ({ user, onLogout }) => {
  const [activeTab, setActiveTab] = useState('profile');
  const [isEditing, setIsEditing] = useState(false);
  const [showVehicleForm, setShowVehicleForm] = useState(false);
  const [showReportForm, setShowReportForm] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedViolation, setSelectedViolation] = useState<Violation | null>(null);

  const [profile, setProfile] = useState<Citizen>({
    id: user.id,
    firstName: 'Jean',
    lastName: 'Baptiste',
    dateOfBirth: '1985-03-15',
    nationalId: 'BF123456789',
    phone: '+226 70 12 34 56',
    address: 'Secteur 15, Ouagadougou',
    email: user.email,
    profession: 'Enseignant',
    emergencyContact: 'Marie Baptiste',
    emergencyPhone: '+226 71 23 45 67',
    registrationDate: '2024-01-15',
    isActive: true
  });

  const [vehicles, setVehicles] = useState<Vehicle[]>([
    { 
      id: '1', 
      ownerId: user.id,
      ownerName: `${profile.firstName} ${profile.lastName}`,
      make: 'Toyota', 
      model: 'Corolla', 
      year: 2020, 
      licensePlate: 'BF-001-AB', 
      color: 'Blanc',
      chassisNumber: 'JT123456789',
      engineNumber: 'EN123456789',
      registrationDate: '2024-01-15',
      insuranceNumber: 'ASS123456',
      insuranceExpiry: '2024-12-31',
      technicalControlExpiry: '2024-06-30',
      isActive: true
    },
    { 
      id: '2', 
      ownerId: user.id,
      ownerName: `${profile.firstName} ${profile.lastName}`,
      make: 'Honda', 
      model: 'Civic', 
      year: 2019, 
      licensePlate: 'BF-002-CD', 
      color: 'Noir',
      chassisNumber: 'HC987654321',
      engineNumber: 'EN987654321',
      registrationDate: '2024-01-10',
      insuranceNumber: 'ASS987654',
      insuranceExpiry: '2024-11-15',
      technicalControlExpiry: '2024-05-20',
      isActive: true
    },
  ]);

  const [violations] = useState<Violation[]>([
    {
      id: '1',
      citizenId: user.id,
      citizenName: `${profile.firstName} ${profile.lastName}`,
      vehicleId: '1',
      vehiclePlate: 'BF-001-AB',
      officerId: '2',
      officerName: 'Commissaire Ouédraogo',
      type: 'Excès de vitesse',
      description: 'Vitesse constatée: 80 km/h en zone 50 km/h',
      fine: 25000,
      date: '2024-01-20',
      location: 'Avenue Kwame Nkrumah',
      status: 'pending'
    },
    {
      id: '2',
      citizenId: user.id,
      citizenName: `${profile.firstName} ${profile.lastName}`,
      vehicleId: '2',
      vehiclePlate: 'BF-002-CD',
      officerId: '2',
      officerName: 'Commissaire Ouédraogo',
      type: 'Stationnement interdit',
      description: 'Stationnement sur place handicapé',
      fine: 15000,
      date: '2024-01-18',
      location: 'Centre-ville',
      status: 'paid',
      paymentDate: '2024-01-25'
    },
    {
      id: '3',
      citizenId: user.id,
      citizenName: `${profile.firstName} ${profile.lastName}`,
      vehicleId: '1',
      vehiclePlate: 'BF-001-AB',
      officerId: '2',
      officerName: 'Commissaire Ouédraogo',
      type: 'Téléphone au volant',
      description: 'Utilisation du téléphone portable en conduisant',
      fine: 20000,
      date: '2024-01-12',
      location: 'Boulevard Charles de Gaulle',
      status: 'contested',
      contestReason: 'Le téléphone était en mode mains libres'
    },
  ]);

  const [reports, setReports] = useState<Report[]>([
    {
      id: '1',
      citizenId: user.id,
      citizenName: `${profile.firstName} ${profile.lastName}`,
      type: 'theft',
      title: 'Vol de téléphone portable',
      description: 'Mon téléphone a été volé dans le transport en commun',
      location: 'Arrêt de bus Wemtenga',
      date: '2024-01-25',
      status: 'investigating',
      assignedOfficer: 'Agent Kaboré',
      priority: 'medium'
    },
    {
      id: '2',
      citizenId: user.id,
      citizenName: `${profile.firstName} ${profile.lastName}`,
      type: 'suspicious',
      title: 'Activité suspecte dans le quartier',
      description: 'Des individus suspects rôdent autour des maisons la nuit',
      location: 'Secteur 15, près de l\'école',
      date: '2024-01-20',
      status: 'resolved',
      assignedOfficer: 'Brigadier Sawadogo',
      priority: 'low'
    },
  ]);

  const handleSaveProfile = () => {
    setIsEditing(false);
    // Ici, on sauvegarderait les données
  };

  const handlePayViolation = (violation: Violation) => {
    setSelectedViolation(violation);
    setShowPaymentModal(true);
  };

  const VehicleForm = () => {
    const [vehicleData, setVehicleData] = useState({
      make: '',
      model: '',
      year: '',
      licensePlate: '',
      color: '',
      chassisNumber: '',
      engineNumber: '',
      insuranceNumber: '',
      insuranceExpiry: '',
      technicalControlExpiry: ''
    });

    const handleSubmit = () => {
      const newVehicle: Vehicle = {
        id: Date.now().toString(),
        ownerId: user.id,
        ownerName: `${profile.firstName} ${profile.lastName}`,
        make: vehicleData.make,
        model: vehicleData.model,
        year: parseInt(vehicleData.year),
        licensePlate: vehicleData.licensePlate,
        color: vehicleData.color,
        chassisNumber: vehicleData.chassisNumber,
        engineNumber: vehicleData.engineNumber,
        registrationDate: new Date().toISOString().split('T')[0],
        insuranceNumber: vehicleData.insuranceNumber,
        insuranceExpiry: vehicleData.insuranceExpiry,
        technicalControlExpiry: vehicleData.technicalControlExpiry,
        isActive: true
      };
      
      setVehicles(prev => [...prev, newVehicle]);
      setShowVehicleForm(false);
    };

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900">Nouveau Véhicule</h3>
            <p className="text-sm text-gray-600 mt-1">Enregistrez un nouveau véhicule</p>
          </div>
          
          <div className="p-6 space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Marque *</label>
                <input
                  type="text"
                  value={vehicleData.make}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, make: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Toyota, Honda, etc."
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Modèle *</label>
                <input
                  type="text"
                  value={vehicleData.model}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, model: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Corolla, Civic, etc."
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Année *</label>
                <input
                  type="number"
                  value={vehicleData.year}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, year: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="2020"
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Couleur *</label>
                <input
                  type="text"
                  value={vehicleData.color}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, color: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Blanc, Noir, etc."
                  required
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Plaque d'immatriculation *</label>
                <input
                  type="text"
                  value={vehicleData.licensePlate}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, licensePlate: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="BF-XXX-XX"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Numéro de châssis</label>
                <input
                  type="text"
                  value={vehicleData.chassisNumber}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, chassisNumber: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Numéro de châssis"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Numéro de moteur</label>
                <input
                  type="text"
                  value={vehicleData.engineNumber}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, engineNumber: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Numéro de moteur"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Numéro d'assurance</label>
                <input
                  type="text"
                  value={vehicleData.insuranceNumber}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, insuranceNumber: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Numéro d'assurance"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Expiration assurance</label>
                <input
                  type="date"
                  value={vehicleData.insuranceExpiry}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, insuranceExpiry: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Expiration contrôle technique</label>
                <input
                  type="date"
                  value={vehicleData.technicalControlExpiry}
                  onChange={(e) => setVehicleData(prev => ({ ...prev, technicalControlExpiry: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>
          </div>
          
          <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
            <button
              onClick={() => setShowVehicleForm(false)}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <button 
              onClick={handleSubmit}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              Enregistrer
            </button>
          </div>
        </div>
      </div>
    );
  };

  const ReportForm = () => {
    const [reportData, setReportData] = useState({
      type: 'theft',
      title: '',
      description: '',
      location: ''
    });

    const reportTypes = [
      { value: 'theft', label: 'Vol' },
      { value: 'accident', label: 'Accident' },
      { value: 'suspicious', label: 'Activité suspecte' },
      { value: 'other', label: 'Autre' }
    ];

    const handleSubmit = () => {
      const newReport: Report = {
        id: Date.now().toString(),
        citizenId: user.id,
        citizenName: `${profile.firstName} ${profile.lastName}`,
        type: reportData.type as 'theft' | 'accident' | 'suspicious' | 'other',
        title: reportData.title,
        description: reportData.description,
        location: reportData.location,
        date: new Date().toISOString().split('T')[0],
        status: 'pending',
        priority: 'medium'
      };
      
      setReports(prev => [...prev, newReport]);
      setShowReportForm(false);
    };

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900">Nouveau Signalement</h3>
            <p className="text-sm text-gray-600 mt-1">Signalez un incident aux forces de l'ordre</p>
          </div>
          
          <div className="p-6 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Type d'incident *</label>
              <select 
                value={reportData.type}
                onChange={(e) => setReportData(prev => ({ ...prev, type: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
              >
                {reportTypes.map(type => (
                  <option key={type.value} value={type.value}>{type.label}</option>
                ))}
              </select>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Titre *</label>
              <input
                type="text"
                value={reportData.title}
                onChange={(e) => setReportData(prev => ({ ...prev, title: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Résumé de l'incident"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Description détaillée *</label>
              <textarea
                rows={4}
                value={reportData.description}
                onChange={(e) => setReportData(prev => ({ ...prev, description: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Décrivez l'incident en détail..."
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Lieu de l'incident *</label>
              <input
                type="text"
                value={reportData.location}
                onChange={(e) => setReportData(prev => ({ ...prev, location: e.target.value }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Adresse ou lieu précis"
                required
              />
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-blue-800 text-sm">
                <strong>Information:</strong> Votre signalement sera transmis aux forces de l'ordre compétentes. 
                Vous serez contacté si des informations supplémentaires sont nécessaires.
              </p>
            </div>
          </div>
          
          <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
            <button
              onClick={() => setShowReportForm(false)}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <button 
              onClick={handleSubmit}
              className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
            >
              Envoyer le signalement
            </button>
          </div>
        </div>
      </div>
    );
  };

  const PaymentModal = () => {
    const [paymentMethod, setPaymentMethod] = useState('mobile_money');
    const [phoneNumber, setPhoneNumber] = useState('');

    if (!selectedViolation) return null;

    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
        <div className="bg-white rounded-xl shadow-2xl max-w-md w-full">
          <div className="p-6 border-b border-gray-200">
            <h3 className="text-xl font-semibold text-gray-900">Paiement de l'amende</h3>
            <p className="text-sm text-gray-600 mt-1">Contravention #{selectedViolation.id}</p>
          </div>
          
          <div className="p-6 space-y-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600 space-y-1">
                <p><strong>Infraction:</strong> {selectedViolation.type}</p>
                <p><strong>Date:</strong> {selectedViolation.date}</p>
                <p><strong>Lieu:</strong> {selectedViolation.location}</p>
                <p><strong>Véhicule:</strong> {selectedViolation.vehiclePlate}</p>
              </div>
              <div className="mt-3 pt-3 border-t border-gray-200">
                <p className="text-lg font-semibold text-gray-900">
                  Montant: {selectedViolation.fine.toLocaleString()} FCFA
                </p>
              </div>
            </div>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Mode de paiement</label>
              <select 
                value={paymentMethod}
                onChange={(e) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="mobile_money">Mobile Money</option>
                <option value="bank_transfer">Virement bancaire</option>
                <option value="cash">Espèces (au commissariat)</option>
              </select>
            </div>
            
            {paymentMethod === 'mobile_money' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Numéro de téléphone</label>
                <input
                  type="tel"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="+226 70 12 34 56"
                />
              </div>
            )}

            {paymentMethod === 'cash' && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <p className="text-yellow-800 text-sm">
                  <strong>Paiement en espèces:</strong> Rendez-vous au commissariat le plus proche 
                  avec cette référence: {selectedViolation.id}
                </p>
              </div>
            )}
          </div>
          
          <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
            <button
              onClick={() => setShowPaymentModal(false)}
              className="px-4 py-2 text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <button className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors">
              {paymentMethod === 'cash' ? 'Confirmer' : 'Payer maintenant'}
            </button>
          </div>
        </div>
      </div>
    );
  };

  const renderProfile = () => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-semibold text-gray-900">Mes Informations Personnelles</h3>
        {!isEditing ? (
          <button
            onClick={() => setIsEditing(true)}
            className="flex items-center px-4 py-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          >
            <Edit className="w-4 h-4 mr-2" />
            Modifier
          </button>
        ) : (
          <div className="flex space-x-2">
            <button
              onClick={handleSaveProfile}
              className="flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
            >
              <Save className="w-4 h-4 mr-2" />
              Sauvegarder
            </button>
            <button
              onClick={() => setIsEditing(false)}
              className="flex items-center px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <X className="w-4 h-4 mr-2" />
              Annuler
            </button>
          </div>
        )}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Prénom</label>
          <input
            type="text"
            value={profile.firstName}
            onChange={(e) => setProfile({...profile, firstName: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Nom</label>
          <input
            type="text"
            value={profile.lastName}
            onChange={(e) => setProfile({...profile, lastName: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Date de naissance</label>
          <input
            type="date"
            value={profile.dateOfBirth}
            onChange={(e) => setProfile({...profile, dateOfBirth: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Carte Nationale d'Identité</label>
          <input
            type="text"
            value={profile.nationalId}
            disabled
            className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-50"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone</label>
          <input
            type="tel"
            value={profile.phone}
            onChange={(e) => setProfile({...profile, phone: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
          <input
            type="email"
            value={profile.email}
            onChange={(e) => setProfile({...profile, email: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Profession</label>
          <input
            type="text"
            value={profile.profession}
            onChange={(e) => setProfile({...profile, profession: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Contact d'urgence</label>
          <input
            type="text"
            value={profile.emergencyContact}
            onChange={(e) => setProfile({...profile, emergencyContact: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>
      </div>
      
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Adresse complète</label>
          <textarea
            value={profile.address}
            onChange={(e) => setProfile({...profile, address: e.target.value})}
            disabled={!isEditing}
            rows={3}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone d'urgence</label>
          <input
            type="tel"
            value={profile.emergencyPhone}
            onChange={(e) => setProfile({...profile, emergencyPhone: e.target.value})}
            disabled={!isEditing}
            className={`w-full px-3 py-2 border border-gray-300 rounded-lg ${
              isEditing ? 'focus:ring-2 focus:ring-blue-500 focus:border-transparent' : 'bg-gray-50'
            }`}
          />
        </div>
      </div>
    </div>
  );

  const renderVehicles = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">Mes Véhicules</h3>
        <button
          onClick={() => setShowVehicleForm(true)}
          className="flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Ajouter un véhicule
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {vehicles.map((vehicle) => (
          <div key={vehicle.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <Car className="w-8 h-8 text-blue-600 mr-3" />
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">
                    {vehicle.make} {vehicle.model}
                  </h4>
                  <p className="text-sm text-gray-500">Année {vehicle.year}</p>
                </div>
              </div>
              <button className="text-gray-400 hover:text-gray-600">
                <Edit className="w-4 h-4" />
              </button>
            </div>
            
            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Plaque:</span>
                <span className="text-sm font-medium text-gray-900">{vehicle.licensePlate}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Couleur:</span>
                <span className="text-sm font-medium text-gray-900">{vehicle.color}</span>
              </div>
              {vehicle.chassisNumber && (
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">Châssis:</span>
                  <span className="text-sm font-medium text-gray-900">{vehicle.chassisNumber}</span>
                </div>
              )}
            </div>

            {/* Alertes d'expiration */}
            <div className="space-y-2">
              <div className={`p-3 rounded-lg ${
                new Date(vehicle.insuranceExpiry) < new Date() ? 'bg-red-50 border border-red-200' : 
                new Date(vehicle.insuranceExpiry) < new Date(Date.now() + 30*24*60*60*1000) ? 'bg-yellow-50 border border-yellow-200' :
                'bg-green-50 border border-green-200'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Assurance</span>
                  <span className={`text-sm ${
                    new Date(vehicle.insuranceExpiry) < new Date() ? 'text-red-800' :
                    new Date(vehicle.insuranceExpiry) < new Date(Date.now() + 30*24*60*60*1000) ? 'text-yellow-800' :
                    'text-green-800'
                  }`}>
                    {vehicle.insuranceExpiry}
                  </span>
                </div>
                {new Date(vehicle.insuranceExpiry) < new Date() && (
                  <p className="text-xs text-red-600 mt-1">⚠️ Assurance expirée</p>
                )}
              </div>

              <div className={`p-3 rounded-lg ${
                new Date(vehicle.technicalControlExpiry) < new Date() ? 'bg-red-50 border border-red-200' : 
                new Date(vehicle.technicalControlExpiry) < new Date(Date.now() + 30*24*60*60*1000) ? 'bg-yellow-50 border border-yellow-200' :
                'bg-green-50 border border-green-200'
              }`}>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Contrôle technique</span>
                  <span className={`text-sm ${
                    new Date(vehicle.technicalControlExpiry) < new Date() ? 'text-red-800' :
                    new Date(vehicle.technicalControlExpiry) < new Date(Date.now() + 30*24*60*60*1000) ? 'text-yellow-800' :
                    'text-green-800'
                  }`}>
                    {vehicle.technicalControlExpiry}
                  </span>
                </div>
                {new Date(vehicle.technicalControlExpiry) < new Date() && (
                  <p className="text-xs text-red-600 mt-1">⚠️ Contrôle technique expiré</p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderViolations = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">Mes Contraventions</h3>
        <button className="flex items-center px-4 py-2 text-gray-600 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg transition-colors">
          <Download className="w-4 h-4 mr-2" />
          Télécharger
        </button>
      </div>
      
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Infraction</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Véhicule</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Lieu</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Amende</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {violations.map((violation) => (
                <tr key={violation.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900">{violation.type}</div>
                    <div className="text-sm text-gray-500">{violation.description}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono text-gray-900">{violation.vehiclePlate}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.location}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{violation.fine.toLocaleString()} FCFA</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                      violation.status === 'paid' ? 'bg-green-100 text-green-800' :
                      violation.status === 'contested' ? 'bg-red-100 text-red-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {violation.status === 'paid' ? 'Payée' :
                       violation.status === 'contested' ? 'Contestée' : 'En attente'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <div className="flex justify-end space-x-2">
                      <button className="text-blue-600 hover:text-blue-900">
                        <Eye className="w-4 h-4" />
                      </button>
                      {violation.status === 'pending' && (
                        <button 
                          onClick={() => handlePayViolation(violation)}
                          className="text-green-600 hover:text-green-900"
                          title="Payer l'amende"
                        >
                          <CreditCard className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );

  const renderReports = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-xl font-semibold text-gray-900">Mes Signalements</h3>
        <button
          onClick={() => setShowReportForm(true)}
          className="flex items-center px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nouveau signalement
        </button>
      </div>
      
      <div className="space-y-4">
        {reports.map((report) => (
          <div key={report.id} className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center">
                <AlertTriangle className="w-6 h-6 text-red-600 mr-3" />
                <div>
                  <h4 className="text-lg font-semibold text-gray-900">{report.title}</h4>
                  <p className="text-sm text-gray-500">
                    {report.type === 'theft' ? 'Vol' :
                     report.type === 'accident' ? 'Accident' :
                     report.type === 'suspicious' ? 'Activité suspecte' : 'Autre'}
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  report.priority === 'high' ? 'bg-red-100 text-red-800' :
                  report.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-gray-100 text-gray-800'
                }`}>
                  {report.priority === 'high' ? 'Haute' : report.priority === 'medium' ? 'Moyenne' : 'Faible'}
                </span>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                  report.status === 'resolved' ? 'bg-green-100 text-green-800' :
                  report.status === 'investigating' ? 'bg-blue-100 text-blue-800' :
                  report.status === 'closed' ? 'bg-gray-100 text-gray-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {report.status === 'resolved' ? 'Résolu' :
                   report.status === 'investigating' ? 'En cours' :
                   report.status === 'closed' ? 'Fermé' : 'En attente'}
                </span>
              </div>
            </div>
            
            <p className="text-gray-700 mb-4">{report.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-gray-600">
              <div className="flex items-center">
                <MapPin className="w-4 h-4 mr-2" />
                <span>{report.location}</span>
              </div>
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-2" />
                <span>{report.date}</span>
              </div>
              {report.assignedOfficer && (
                <div className="flex items-center">
                  <UserIcon className="w-4 h-4 mr-2" />
                  <span>Assigné à: {report.assignedOfficer}</span>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderContent = () => {
    switch (activeTab) {
      case 'profile': return renderProfile();
      case 'vehicles': return renderVehicles();
      case 'violations': return renderViolations();
      case 'reports': return renderReports();
      default: return <div>Section en cours de développement</div>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header user={user} onLogout={onLogout} />
      
      <div className="p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Mon Espace Citoyen</h1>
          <p className="text-gray-600">Gérez vos informations et suivez vos démarches</p>
        </div>
        
        {/* Alertes importantes */}
        <div className="mb-6 space-y-3">
          {violations.some(v => v.status === 'pending') && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-center">
                <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3" />
                <div>
                  <p className="text-yellow-800 font-medium">
                    Vous avez {violations.filter(v => v.status === 'pending').length} contravention(s) en attente de paiement
                  </p>
                  <p className="text-yellow-700 text-sm">
                    Montant total: {violations.filter(v => v.status === 'pending').reduce((sum, v) => sum + v.fine, 0).toLocaleString()} FCFA
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {vehicles.some(v => new Date(v.insuranceExpiry) < new Date() || new Date(v.technicalControlExpiry) < new Date()) && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-center">
                <AlertTriangle className="w-5 h-5 text-red-600 mr-3" />
                <div>
                  <p className="text-red-800 font-medium">
                    Certains de vos véhicules ont des documents expirés
                  </p>
                  <p className="text-red-700 text-sm">
                    Vérifiez vos assurances et contrôles techniques dans l'onglet "Mes Véhicules"
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
        
        <div className="mb-6">
          <nav className="flex space-x-1 bg-white rounded-lg p-1 shadow-sm border border-gray-200">
            {[
              { id: 'profile', label: 'Mon Profil', icon: UserIcon },
              { id: 'vehicles', label: 'Mes Véhicules', icon: Car },
              { id: 'violations', label: 'Mes Contraventions', icon: FileX },
              { id: 'reports', label: 'Mes Signalements', icon: AlertTriangle },
            ].map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                  activeTab === item.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:text-gray-900 hover:bg-gray-50'
                }`}
              >
                <item.icon className="w-4 h-4 mr-2" />
                {item.label}
                {item.id === 'violations' && violations.filter(v => v.status === 'pending').length > 0 && (
                  <span className="ml-2 bg-red-500 text-white text-xs rounded-full px-2 py-1">
                    {violations.filter(v => v.status === 'pending').length}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
        
        {renderContent()}
      </div>
      
      {showVehicleForm && <VehicleForm />}
      {showReportForm && <ReportForm />}
      {showPaymentModal && <PaymentModal />}
    </div>
  );
};

export default CitizenDashboard;