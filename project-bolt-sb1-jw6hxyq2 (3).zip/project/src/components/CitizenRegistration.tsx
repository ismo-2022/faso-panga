import React, { useState } from 'react';
import { Shield, ArrowLeft, User, Phone, MapPin, Briefcase, Save, Camera } from 'lucide-react';

interface CitizenRegistrationProps {
  onSuccess: (userData: any) => void;
  onBack: () => void;
}

const CitizenRegistration: React.FC<CitizenRegistrationProps> = ({ onSuccess, onBack }) => {
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    // Informations personnelles
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    nationalId: '',
    phone: '',
    email: '',
    address: '',
    profession: '',
    emergencyContact: '',
    emergencyPhone: '',
    
    // Véhicules (optionnel)
    vehicles: [] as any[]
  });

  const [currentVehicle, setCurrentVehicle] = useState({
    make: '',
    model: '',
    year: '',
    licensePlate: '',
    color: '',
    chassisNumber: '',
    engineNumber: '',
    insuranceNumber: '',
    insuranceExpiry: '',
    technicalControlExpiry: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleVehicleChange = (field: string, value: string) => {
    setCurrentVehicle(prev => ({ ...prev, [field]: value }));
  };

  const addVehicle = () => {
    if (currentVehicle.make && currentVehicle.model && currentVehicle.licensePlate) {
      setFormData(prev => ({
        ...prev,
        vehicles: [...prev.vehicles, { ...currentVehicle, id: Date.now().toString() }]
      }));
      setCurrentVehicle({
        make: '',
        model: '',
        year: '',
        licensePlate: '',
        color: '',
        chassisNumber: '',
        engineNumber: '',
        insuranceNumber: '',
        insuranceExpiry: '',
        technicalControlExpiry: ''
      });
    }
  };

  const removeVehicle = (index: number) => {
    setFormData(prev => ({
      ...prev,
      vehicles: prev.vehicles.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    
    // Simulation de l'enregistrement
    setTimeout(() => {
      onSuccess(formData);
      setIsLoading(false);
    }, 2000);
  };

  const renderStep1 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Informations Personnelles</h2>
        <p className="text-gray-600">Veuillez remplir vos informations personnelles</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Prénom *</label>
          <input
            type="text"
            value={formData.firstName}
            onChange={(e) => handleInputChange('firstName', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Votre prénom"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Nom *</label>
          <input
            type="text"
            value={formData.lastName}
            onChange={(e) => handleInputChange('lastName', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Votre nom"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Date de naissance *</label>
          <input
            type="date"
            value={formData.dateOfBirth}
            onChange={(e) => handleInputChange('dateOfBirth', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Carte Nationale d'Identité *</label>
          <input
            type="text"
            value={formData.nationalId}
            onChange={(e) => handleInputChange('nationalId', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="BF123456789"
            required
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone *</label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => handleInputChange('phone', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="+226 70 12 34 56"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => handleInputChange('email', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="votre.email@exemple.com"
            required
          />
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Adresse complète *</label>
        <textarea
          value={formData.address}
          onChange={(e) => handleInputChange('address', e.target.value)}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="Secteur, quartier, ville..."
          required
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Profession</label>
        <input
          type="text"
          value={formData.profession}
          onChange={(e) => handleInputChange('profession', e.target.value)}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          placeholder="Votre profession"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Contact d'urgence</label>
          <input
            type="text"
            value={formData.emergencyContact}
            onChange={(e) => handleInputChange('emergencyContact', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="Nom du contact d'urgence"
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Téléphone d'urgence</label>
          <input
            type="tel"
            value={formData.emergencyPhone}
            onChange={(e) => handleInputChange('emergencyPhone', e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="+226 70 12 34 56"
          />
        </div>
      </div>
    </div>
  );

  const renderStep2 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Véhicules (Optionnel)</h2>
        <p className="text-gray-600">Enregistrez vos véhicules pour faciliter les contrôles</p>
      </div>

      {/* Liste des véhicules ajoutés */}
      {formData.vehicles.length > 0 && (
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Véhicules enregistrés</h3>
          <div className="space-y-3">
            {formData.vehicles.map((vehicle, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900">{vehicle.make} {vehicle.model} ({vehicle.year})</p>
                  <p className="text-sm text-gray-600">Plaque: {vehicle.licensePlate} - Couleur: {vehicle.color}</p>
                </div>
                <button
                  onClick={() => removeVehicle(index)}
                  className="text-red-600 hover:text-red-800 px-3 py-1 rounded"
                >
                  Supprimer
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Formulaire d'ajout de véhicule */}
      <div className="border border-gray-200 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Ajouter un véhicule</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Marque</label>
            <input
              type="text"
              value={currentVehicle.make}
              onChange={(e) => handleVehicleChange('make', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Toyota, Honda, etc."
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Modèle</label>
            <input
              type="text"
              value={currentVehicle.model}
              onChange={(e) => handleVehicleChange('model', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Corolla, Civic, etc."
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Année</label>
            <input
              type="number"
              value={currentVehicle.year}
              onChange={(e) => handleVehicleChange('year', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="2020"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Couleur</label>
            <input
              type="text"
              value={currentVehicle.color}
              onChange={(e) => handleVehicleChange('color', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Blanc, Noir, etc."
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Plaque d'immatriculation</label>
            <input
              type="text"
              value={currentVehicle.licensePlate}
              onChange={(e) => handleVehicleChange('licensePlate', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="BF-001-AB"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Numéro de châssis</label>
            <input
              type="text"
              value={currentVehicle.chassisNumber}
              onChange={(e) => handleVehicleChange('chassisNumber', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Numéro de châssis"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Numéro de moteur</label>
            <input
              type="text"
              value={currentVehicle.engineNumber}
              onChange={(e) => handleVehicleChange('engineNumber', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Numéro de moteur"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Numéro d'assurance</label>
            <input
              type="text"
              value={currentVehicle.insuranceNumber}
              onChange={(e) => handleVehicleChange('insuranceNumber', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="Numéro d'assurance"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Expiration assurance</label>
            <input
              type="date"
              value={currentVehicle.insuranceExpiry}
              onChange={(e) => handleVehicleChange('insuranceExpiry', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Expiration contrôle technique</label>
            <input
              type="date"
              value={currentVehicle.technicalControlExpiry}
              onChange={(e) => handleVehicleChange('technicalControlExpiry', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        <button
          onClick={addVehicle}
          className="w-full bg-green-600 hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
        >
          Ajouter ce véhicule
        </button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="space-y-6">
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">Confirmation</h2>
        <p className="text-gray-600">Vérifiez vos informations avant de finaliser l'enregistrement</p>
      </div>

      <div className="bg-gray-50 rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Informations personnelles</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div><strong>Nom complet:</strong> {formData.firstName} {formData.lastName}</div>
          <div><strong>Date de naissance:</strong> {formData.dateOfBirth}</div>
          <div><strong>CNI:</strong> {formData.nationalId}</div>
          <div><strong>Téléphone:</strong> {formData.phone}</div>
          <div><strong>Email:</strong> {formData.email}</div>
          <div><strong>Profession:</strong> {formData.profession || 'Non spécifiée'}</div>
        </div>
        <div className="mt-4">
          <strong>Adresse:</strong> {formData.address}
        </div>
      </div>

      {formData.vehicles.length > 0 && (
        <div className="bg-gray-50 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Véhicules enregistrés ({formData.vehicles.length})</h3>
          <div className="space-y-3">
            {formData.vehicles.map((vehicle, index) => (
              <div key={index} className="bg-white p-3 rounded border">
                <div className="font-medium">{vehicle.make} {vehicle.model} ({vehicle.year})</div>
                <div className="text-sm text-gray-600">Plaque: {vehicle.licensePlate} - Couleur: {vehicle.color}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <p className="text-blue-800 text-sm">
          <strong>Important:</strong> En vous enregistrant, vous acceptez que vos informations soient utilisées 
          par les forces de l'ordre dans le cadre de leurs missions de sécurité publique. 
          Vos données sont protégées et ne seront pas partagées avec des tiers.
        </p>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/20"></div>
      
      <div className="relative max-w-4xl w-full">
        <div className="bg-white rounded-2xl shadow-2xl p-8 backdrop-blur-sm border border-white/10">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={onBack}
              className="flex items-center text-gray-600 hover:text-gray-900 transition-colors"
            >
              <ArrowLeft className="w-5 h-5 mr-2" />
              Retour à la connexion
            </button>
            
            <div className="flex items-center">
              <Shield className="w-8 h-8 text-blue-600 mr-3" />
              <div>
                <h1 className="text-xl font-bold text-gray-900">FASO PANGA</h1>
                <p className="text-sm text-gray-500">Enregistrement Citoyen</p>
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-gray-600">Étape {currentStep} sur 3</span>
              <span className="text-sm text-gray-500">
                {currentStep === 1 ? 'Informations personnelles' : 
                 currentStep === 2 ? 'Véhicules' : 'Confirmation'}
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / 3) * 100}%` }}
              ></div>
            </div>
          </div>

          {/* Content */}
          <div className="mb-8">
            {currentStep === 1 && renderStep1()}
            {currentStep === 2 && renderStep2()}
            {currentStep === 3 && renderStep3()}
          </div>

          {/* Navigation buttons */}
          <div className="flex justify-between">
            <button
              onClick={() => setCurrentStep(Math.max(1, currentStep - 1))}
              disabled={currentStep === 1}
              className="px-6 py-2 text-gray-600 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Précédent
            </button>
            
            {currentStep < 3 ? (
              <button
                onClick={() => setCurrentStep(currentStep + 1)}
                disabled={
                  currentStep === 1 && (!formData.firstName || !formData.lastName || !formData.nationalId || !formData.phone || !formData.email || !formData.address)
                }
                className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Suivant
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={isLoading}
                className="flex items-center px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isLoading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Enregistrement...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 mr-2" />
                    Finaliser l'enregistrement
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CitizenRegistration;