import React, { useState } from 'react';
import { Shield, User, Eye, EyeOff, UserPlus } from 'lucide-react';
import { User as UserType } from '../types';
import CitizenRegistration from './CitizenRegistration';

interface LoginPageProps {
  onLogin: (user: UserType) => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [showRegistration, setShowRegistration] = useState(false);

  // Utilisateurs de démonstration
  const demoUsers: UserType[] = [
    {
      id: '1',
      name: 'Administrateur Système',
      email: 'admin@fasopanga.gov.bf',
      role: 'admin',
      createdAt: '2024-01-01',
      isActive: true
    },
    {
      id: '2',
      name: 'Commissaire Ouédraogo',
      email: 'police@fasopanga.gov.bf',
      role: 'police',
      badge: 'FP-001',
      department: 'Police Municipale',
      createdAt: '2024-01-01',
      isActive: true
    },
    {
      id: '3',
      name: 'Jean Baptiste',
      email: 'citoyen@email.com',
      role: 'citizen',
      createdAt: '2024-01-01',
      isActive: true
    }
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulation d'une authentification
    setTimeout(() => {
      const user = demoUsers.find(u => u.email === email);
      if (user) {
        onLogin(user);
      } else {
        alert('Utilisateur non trouvé. Utilisez un des emails de démonstration.');
      }
      setIsLoading(false);
    }, 1000);
  };

  const handleRegistrationSuccess = (userData: any) => {
    // Créer un utilisateur citoyen après l'enregistrement
    const newUser: UserType = {
      id: Date.now().toString(),
      name: `${userData.firstName} ${userData.lastName}`,
      email: userData.email,
      role: 'citizen',
      createdAt: new Date().toISOString(),
      isActive: true
    };
    onLogin(newUser);
  };

  if (showRegistration) {
    return (
      <CitizenRegistration 
        onSuccess={handleRegistrationSuccess}
        onBack={() => setShowRegistration(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/20"></div>
      
      <div className="relative max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-2xl p-8 backdrop-blur-sm border border-white/10">
          {/* Logo et titre */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-600 rounded-full mb-4 shadow-lg">
              <Shield className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">FASO PANGA</h1>
            <p className="text-gray-600">Système des Forces de l'Ordre</p>
            <p className="text-sm text-gray-500 mt-1">République du Burkina Faso</p>
          </div>

          {/* Formulaire de connexion */}
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adresse email
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                  placeholder="votre.email@exemple.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Mot de passe
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-4 pr-10 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200"
                  placeholder="••••••••"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 transform hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed shadow-lg"
            >
              {isLoading ? (
                <div className="flex items-center justify-center">
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Connexion...
                </div>
              ) : (
                'Se connecter'
              )}
            </button>
          </form>

          {/* Bouton d'enregistrement pour les citoyens */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <button
              onClick={() => setShowRegistration(true)}
              className="w-full flex items-center justify-center px-4 py-3 border border-blue-600 text-blue-600 hover:bg-blue-50 rounded-lg transition-all duration-200 font-medium"
            >
              <UserPlus className="w-5 h-5 mr-2" />
              S'enregistrer comme citoyen
            </button>
          </div>

          {/* Comptes de démonstration */}
          <div className="mt-8 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-sm font-medium text-gray-700 mb-2">Comptes de démonstration :</h3>
            <div className="space-y-2 text-xs text-gray-600">
              <div>👨‍💼 Admin: admin@fasopanga.gov.bf</div>
              <div>👮‍♂️ Police: police@fasopanga.gov.bf</div>
              <div>👤 Citoyen: citoyen@email.com</div>
              <p className="text-gray-500 mt-2">Mot de passe: n'importe lequel</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;