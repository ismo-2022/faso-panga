const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');

async function initDatabase() {
  try {
    console.log('🚀 Initialisation de la base de données...');

    // Attendre que les tables soient créées
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Créer un utilisateur admin par défaut
    const adminId = uuidv4();
    const hashedPassword = await bcrypt.hash('admin123', 12);

    await db.run(
      `INSERT OR IGNORE INTO users (id, name, email, password, role, created_at)
       VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [adminId, 'Administrateur Système', 'admin@fasopanga.gov.bf', hashedPassword, 'admin']
    );

    // Créer un utilisateur police par défaut
    const policeId = uuidv4();
    const policePassword = await bcrypt.hash('police123', 12);

    await db.run(
      `INSERT OR IGNORE INTO users (id, name, email, password, role, badge, department, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [policeId, 'Commissaire Ouédraogo', 'police@fasopanga.gov.bf', policePassword, 'police', 'FP-001', 'Police Municipale']
    );

    // Créer un utilisateur citoyen par défaut
    const citizenUserId = uuidv4();
    const citizenPassword = await bcrypt.hash('citoyen123', 12);

    await db.run(
      `INSERT OR IGNORE INTO users (id, name, email, password, role, created_at)
       VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [citizenUserId, 'Jean Baptiste', 'citoyen@email.com', citizenPassword, 'citizen']
    );

    // Créer le profil citoyen correspondant
    const citizenId = uuidv4();
    await db.run(
      `INSERT OR IGNORE INTO citizens (
        id, user_id, first_name, last_name, date_of_birth, national_id,
        phone, email, address, profession, emergency_contact, emergency_phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        citizenId, citizenUserId, 'Jean', 'Baptiste', '1985-03-15', 'BF123456789',
        '+226 70 12 34 56', 'citoyen@email.com', 'Secteur 15, Ouagadougou',
        'Enseignant', 'Marie Baptiste', '+226 71 23 45 67'
      ]
    );

    // Créer quelques véhicules d'exemple
    const vehicle1Id = uuidv4();
    await db.run(
      `INSERT OR IGNORE INTO vehicles (
        id, owner_id, owner_name, make, model, year, license_plate, color,
        chassis_number, engine_number, insurance_number, insurance_expiry, technical_control_expiry
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        vehicle1Id, citizenId, 'Jean Baptiste', 'Toyota', 'Corolla', 2020, 'BF-001-AB', 'Blanc',
        'JT123456789', 'EN123456789', 'ASS123456', '2024-12-31', '2024-06-30'
      ]
    );

    // Créer quelques contraventions d'exemple
    const violation1Id = uuidv4();
    await db.run(
      `INSERT OR IGNORE INTO violations (
        id, citizen_id, citizen_name, vehicle_id, vehicle_plate, officer_id, officer_name,
        type, description, fine, date, location, status
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        violation1Id, citizenId, 'Jean Baptiste', vehicle1Id, 'BF-001-AB', policeId, 'Commissaire Ouédraogo',
        'Excès de vitesse', 'Vitesse constatée: 80 km/h en zone 50 km/h', 25000,
        '2024-01-20', 'Avenue Kwame Nkrumah', 'pending'
      ]
    );

    // Créer un avis de recherche d'exemple
    const noticeId = uuidv4();
    const targetDetails = JSON.stringify({
      name: 'Inconnu',
      physicalDescription: 'Homme, 25-30 ans, 1m75, cicatrice joue droite',
      lastSeenLocation: 'Marché central'
    });

    await db.run(
      `INSERT OR IGNORE INTO search_notices (
        id, type, title, description, target_details, issued_by, priority, reward, contact_info
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        noticeId, 'person', 'Vol de véhicule - Suspect recherché',
        'Individu suspecté de vol de véhicule, armé et dangereux',
        targetDetails, policeId, 'high', 100000, '+226 70 00 00 00'
      ]
    );

    console.log('✅ Base de données initialisée avec succès!');
    console.log('📋 Comptes créés:');
    console.log('   👨‍💼 Admin: admin@fasopanga.gov.bf / admin123');
    console.log('   👮‍♂️ Police: police@fasopanga.gov.bf / police123');
    console.log('   👤 Citoyen: citoyen@email.com / citoyen123');

  } catch (error) {
    console.error('❌ Erreur initialisation base de données:', error);
  } finally {
    await db.close();
    process.exit(0);
  }
}

// Exécuter l'initialisation
initDatabase();