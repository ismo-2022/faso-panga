const jwt = require('jsonwebtoken');
const db = require('../config/database');

const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ 
      error: 'Token d\'accès requis',
      message: 'Veuillez vous connecter pour accéder à cette ressource'
    });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Vérifier que l'utilisateur existe toujours
    const user = await db.query(
      'SELECT id, name, email, role, is_active FROM users WHERE id = ?',
      [decoded.userId]
    );

    if (!user.length || !user[0].is_active) {
      return res.status(401).json({ 
        error: 'Token invalide',
        message: 'Utilisateur non trouvé ou désactivé'
      });
    }

    req.user = user[0];
    next();
  } catch (error) {
    return res.status(403).json({ 
      error: 'Token invalide',
      message: 'Le token fourni n\'est pas valide'
    });
  }
};

const authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ 
        error: 'Non authentifié',
        message: 'Authentification requise'
      });
    }

    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        error: 'Accès refusé',
        message: 'Vous n\'avez pas les permissions nécessaires pour cette action'
      });
    }

    next();
  };
};

const logActivity = async (req, res, next) => {
  if (req.user) {
    try {
      await db.run(
        `INSERT INTO activity_logs (id, user_id, action, resource, resource_id, details, ip_address, user_agent)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          require('uuid').v4(),
          req.user.id,
          req.method,
          req.route?.path || req.path,
          req.params.id || null,
          JSON.stringify(req.body),
          req.ip,
          req.get('User-Agent')
        ]
      );
    } catch (error) {
      console.error('Erreur log activité:', error);
    }
  }
  next();
};

module.exports = {
  authenticateToken,
  authorizeRoles,
  logActivity
};