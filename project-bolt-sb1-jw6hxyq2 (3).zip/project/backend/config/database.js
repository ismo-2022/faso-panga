const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

const dbPath = process.env.DB_PATH || './database/fasopanga.db';
const dbDir = path.dirname(dbPath);

// Créer le dossier database s'il n'existe pas
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

class Database {
  constructor() {
    this.db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        console.error('❌ Erreur de connexion à la base de données:', err.message);
      } else {
        console.log('✅ Connexion à la base de données SQLite établie');
        this.initTables();
      }
    });
  }

  initTables() {
    const tables = [
      // Table des utilisateurs
      `CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT CHECK(role IN ('admin', 'police', 'citizen')) NOT NULL,
        badge TEXT,
        department TEXT,
        phone TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT 1
      )`,

      // Table des citoyens
      `CREATE TABLE IF NOT EXISTS citizens (
        id TEXT PRIMARY KEY,
        user_id TEXT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        date_of_birth DATE NOT NULL,
        national_id TEXT UNIQUE NOT NULL,
        phone TEXT NOT NULL,
        email TEXT,
        address TEXT NOT NULL,
        profession TEXT,
        emergency_contact TEXT,
        emergency_phone TEXT,
        photo TEXT,
        registration_date DATE DEFAULT CURRENT_DATE,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`,

      // Table des véhicules
      `CREATE TABLE IF NOT EXISTS vehicles (
        id TEXT PRIMARY KEY,
        owner_id TEXT NOT NULL,
        owner_name TEXT NOT NULL,
        make TEXT NOT NULL,
        model TEXT NOT NULL,
        year INTEGER NOT NULL,
        license_plate TEXT UNIQUE NOT NULL,
        color TEXT NOT NULL,
        chassis_number TEXT,
        engine_number TEXT,
        registration_date DATE DEFAULT CURRENT_DATE,
        insurance_number TEXT,
        insurance_expiry DATE,
        technical_control_expiry DATE,
        is_active BOOLEAN DEFAULT 1,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (owner_id) REFERENCES citizens (id)
      )`,

      // Table des contraventions
      `CREATE TABLE IF NOT EXISTS violations (
        id TEXT PRIMARY KEY,
        citizen_id TEXT NOT NULL,
        citizen_name TEXT NOT NULL,
        vehicle_id TEXT,
        vehicle_plate TEXT,
        officer_id TEXT NOT NULL,
        officer_name TEXT NOT NULL,
        type TEXT NOT NULL,
        description TEXT NOT NULL,
        fine DECIMAL(10,2) NOT NULL,
        date DATE NOT NULL,
        location TEXT NOT NULL,
        status TEXT CHECK(status IN ('pending', 'paid', 'contested', 'cancelled')) DEFAULT 'pending',
        payment_date DATE,
        contest_reason TEXT,
        evidence TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (citizen_id) REFERENCES citizens (id),
        FOREIGN KEY (vehicle_id) REFERENCES vehicles (id),
        FOREIGN KEY (officer_id) REFERENCES users (id)
      )`,

      // Table des avis de recherche
      `CREATE TABLE IF NOT EXISTS search_notices (
        id TEXT PRIMARY KEY,
        type TEXT CHECK(type IN ('person', 'vehicle')) NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        target_details TEXT NOT NULL,
        issued_by TEXT NOT NULL,
        issue_date DATE DEFAULT CURRENT_DATE,
        status TEXT CHECK(status IN ('active', 'resolved', 'cancelled')) DEFAULT 'active',
        priority TEXT CHECK(priority IN ('low', 'medium', 'high')) DEFAULT 'medium',
        reward DECIMAL(10,2),
        contact_info TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (issued_by) REFERENCES users (id)
      )`,

      // Table des signalements
      `CREATE TABLE IF NOT EXISTS reports (
        id TEXT PRIMARY KEY,
        citizen_id TEXT NOT NULL,
        citizen_name TEXT NOT NULL,
        type TEXT CHECK(type IN ('theft', 'accident', 'suspicious', 'other')) NOT NULL,
        title TEXT NOT NULL,
        description TEXT NOT NULL,
        location TEXT NOT NULL,
        date DATE DEFAULT CURRENT_DATE,
        status TEXT CHECK(status IN ('pending', 'investigating', 'resolved', 'closed')) DEFAULT 'pending',
        assigned_officer TEXT,
        evidence TEXT,
        priority TEXT CHECK(priority IN ('low', 'medium', 'high')) DEFAULT 'medium',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (citizen_id) REFERENCES citizens (id),
        FOREIGN KEY (assigned_officer) REFERENCES users (id)
      )`,

      // Table des paiements
      `CREATE TABLE IF NOT EXISTS payments (
        id TEXT PRIMARY KEY,
        violation_id TEXT NOT NULL,
        citizen_id TEXT NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        payment_method TEXT CHECK(payment_method IN ('cash', 'mobile_money', 'bank_transfer')) NOT NULL,
        payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        receipt_number TEXT UNIQUE NOT NULL,
        status TEXT CHECK(status IN ('completed', 'pending', 'failed')) DEFAULT 'pending',
        transaction_id TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (violation_id) REFERENCES violations (id),
        FOREIGN KEY (citizen_id) REFERENCES citizens (id)
      )`,

      // Table des logs d'activité
      `CREATE TABLE IF NOT EXISTS activity_logs (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        action TEXT NOT NULL,
        resource TEXT NOT NULL,
        resource_id TEXT,
        details TEXT,
        ip_address TEXT,
        user_agent TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`
    ];

    tables.forEach((table, index) => {
      this.db.run(table, (err) => {
        if (err) {
          console.error(`❌ Erreur création table ${index + 1}:`, err.message);
        } else {
          console.log(`✅ Table ${index + 1} créée/vérifiée`);
        }
      });
    });

    // Créer les index pour optimiser les performances
    this.createIndexes();
  }

  createIndexes() {
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)',
      'CREATE INDEX IF NOT EXISTS idx_citizens_national_id ON citizens(national_id)',
      'CREATE INDEX IF NOT EXISTS idx_vehicles_license_plate ON vehicles(license_plate)',
      'CREATE INDEX IF NOT EXISTS idx_violations_citizen_id ON violations(citizen_id)',
      'CREATE INDEX IF NOT EXISTS idx_violations_status ON violations(status)',
      'CREATE INDEX IF NOT EXISTS idx_reports_citizen_id ON reports(citizen_id)',
      'CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status)',
      'CREATE INDEX IF NOT EXISTS idx_payments_violation_id ON payments(violation_id)'
    ];

    indexes.forEach(index => {
      this.db.run(index, (err) => {
        if (err) {
          console.error('❌ Erreur création index:', err.message);
        }
      });
    });
  }

  query(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  run(sql, params = []) {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({ id: this.lastID, changes: this.changes });
        }
      });
    });
  }

  close() {
    return new Promise((resolve, reject) => {
      this.db.close((err) => {
        if (err) {
          reject(err);
        } else {
          console.log('🔒 Connexion à la base de données fermée');
          resolve();
        }
      });
    });
  }
}

module.exports = new Database();