const express = require('express');
const bcrypt = require('bcryptjs');
const { body, validationResult } = require('express-validator');
const db = require('../config/database');
const { authenticateToken, authorizeRoles, logActivity } = require('../middleware/auth');

const router = express.Router();

// Obtenir tous les utilisateurs (Admin seulement)
router.get('/', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const { role, status, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT id, name, email, role, badge, department, phone, created_at, is_active FROM users WHERE 1=1';
    let params = [];

    if (role) {
      query += ' AND role = ?';
      params.push(role);
    }

    if (status !== undefined) {
      query += ' AND is_active = ?';
      params.push(status === 'active' ? 1 : 0);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const users = await db.query(query, params);

    res.json({ users });

  } catch (error) {
    console.error('Erreur récupération utilisateurs:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les utilisateurs'
    });
  }
});

// Obtenir un utilisateur par ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Vérifier les permissions
    if (req.user.role !== 'admin' && req.user.id !== id) {
      return res.status(403).json({
        error: 'Accès refusé',
        message: 'Vous ne pouvez consulter que votre propre profil'
      });
    }

    const users = await db.query(
      'SELECT id, name, email, role, badge, department, phone, created_at, is_active FROM users WHERE id = ?',
      [id]
    );
    
    if (!users.length) {
      return res.status(404).json({
        error: 'Utilisateur non trouvé',
        message: 'Aucun utilisateur trouvé avec cet ID'
      });
    }

    res.json({ user: users[0] });

  } catch (error) {
    console.error('Erreur récupération utilisateur:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer l\'utilisateur'
    });
  }
});

// Mettre à jour un utilisateur
router.put('/:id', authenticateToken, [
  body('name').optional().trim().isLength({ min: 2 }).withMessage('Le nom doit contenir au moins 2 caractères'),
  body('email').optional().isEmail().withMessage('Email invalide'),
  body('phone').optional().trim().isLength({ min: 8 }).withMessage('Le téléphone doit contenir au moins 8 caractères')
], logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const { id } = req.params;
    const { name, email, phone, badge, department } = req.body;

    // Vérifier les permissions
    if (req.user.role !== 'admin' && req.user.id !== id) {
      return res.status(403).json({
        error: 'Accès refusé',
        message: 'Vous ne pouvez modifier que votre propre profil'
      });
    }

    // Vérifier si l'email existe déjà (sauf pour cet utilisateur)
    if (email) {
      const existingUser = await db.query('SELECT id FROM users WHERE email = ? AND id != ?', [email, id]);
      if (existingUser.length > 0) {
        return res.status(409).json({
          error: 'Email déjà utilisé',
          message: 'Un autre utilisateur utilise déjà cet email'
        });
      }
    }

    // Construire la requête de mise à jour
    let updateFields = [];
    let updateParams = [];

    if (name !== undefined) {
      updateFields.push('name = ?');
      updateParams.push(name);
    }
    if (email !== undefined) {
      updateFields.push('email = ?');
      updateParams.push(email);
    }
    if (phone !== undefined) {
      updateFields.push('phone = ?');
      updateParams.push(phone);
    }
    if (badge !== undefined && req.user.role === 'admin') {
      updateFields.push('badge = ?');
      updateParams.push(badge);
    }
    if (department !== undefined && req.user.role === 'admin') {
      updateFields.push('department = ?');
      updateParams.push(department);
    }

    if (updateFields.length === 0) {
      return res.status(400).json({
        error: 'Aucune donnée à mettre à jour',
        message: 'Veuillez fournir au moins un champ à modifier'
      });
    }

    updateFields.push('updated_at = CURRENT_TIMESTAMP');
    updateParams.push(id);

    const result = await db.run(
      `UPDATE users SET ${updateFields.join(', ')} WHERE id = ?`,
      updateParams
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Utilisateur non trouvé',
        message: 'Aucun utilisateur trouvé avec cet ID'
      });
    }

    const updatedUser = await db.query(
      'SELECT id, name, email, role, badge, department, phone, created_at, is_active FROM users WHERE id = ?',
      [id]
    );

    res.json({
      message: 'Utilisateur mis à jour avec succès',
      user: updatedUser[0]
    });

  } catch (error) {
    console.error('Erreur mise à jour utilisateur:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de mettre à jour l\'utilisateur'
    });
  }
});

// Désactiver un utilisateur (Admin seulement)
router.patch('/:id/deactivate', authenticateToken, authorizeRoles('admin'), logActivity, async (req, res) => {
  try {
    const { id } = req.params;

    // Ne pas permettre à l'admin de se désactiver lui-même
    if (req.user.id === id) {
      return res.status(400).json({
        error: 'Action interdite',
        message: 'Vous ne pouvez pas désactiver votre propre compte'
      });
    }

    const result = await db.run(
      'UPDATE users SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Utilisateur non trouvé',
        message: 'Aucun utilisateur trouvé avec cet ID'
      });
    }

    res.json({
      message: 'Utilisateur désactivé avec succès'
    });

  } catch (error) {
    console.error('Erreur désactivation utilisateur:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de désactiver l\'utilisateur'
    });
  }
});

// Réactiver un utilisateur (Admin seulement)
router.patch('/:id/activate', authenticateToken, authorizeRoles('admin'), logActivity, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.run(
      'UPDATE users SET is_active = 1, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Utilisateur non trouvé',
        message: 'Aucun utilisateur trouvé avec cet ID'
      });
    }

    res.json({
      message: 'Utilisateur réactivé avec succès'
    });

  } catch (error) {
    console.error('Erreur réactivation utilisateur:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de réactiver l\'utilisateur'
    });
  }
});

// Obtenir les logs d'activité d'un utilisateur
router.get('/:id/activity', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 50, offset = 0 } = req.query;

    // Vérifier les permissions
    if (req.user.role !== 'admin' && req.user.id !== id) {
      return res.status(403).json({
        error: 'Accès refusé',
        message: 'Vous ne pouvez consulter que votre propre activité'
      });
    }

    const activities = await db.query(
      `SELECT action, resource, resource_id, details, ip_address, created_at
       FROM activity_logs 
       WHERE user_id = ? 
       ORDER BY created_at DESC 
       LIMIT ? OFFSET ?`,
      [id, parseInt(limit), parseInt(offset)]
    );

    res.json({ activities });

  } catch (error) {
    console.error('Erreur récupération activité:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer l\'activité'
    });
  }
});

// Statistiques des utilisateurs (Admin seulement)
router.get('/stats/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      db.query('SELECT COUNT(*) as total FROM users'),
      db.query('SELECT COUNT(*) as active FROM users WHERE is_active = 1'),
      db.query('SELECT COUNT(*) as admins FROM users WHERE role = "admin"'),
      db.query('SELECT COUNT(*) as police FROM users WHERE role = "police"'),
      db.query('SELECT COUNT(*) as citizens FROM users WHERE role = "citizen"'),
      db.query('SELECT COUNT(*) as recent FROM users WHERE created_at >= date("now", "-30 days")')
    ]);

    res.json({
      total: stats[0][0].total,
      active: stats[1][0].active,
      admins: stats[2][0].admins,
      police: stats[3][0].police,
      citizens: stats[4][0].citizens,
      recentRegistrations: stats[5][0].recent
    });

  } catch (error) {
    console.error('Erreur statistiques utilisateurs:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

module.exports = router;