const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticateToken, authorizeRoles, logActivity } = require('../middleware/auth');

const router = express.Router();

// Validation rules
const paymentValidation = [
  body('violationId').isUUID().withMessage('ID contravention invalide'),
  body('amount').isFloat({ min: 0 }).withMessage('Le montant doit être positif'),
  body('paymentMethod').isIn(['cash', 'mobile_money', 'bank_transfer']).withMessage('Mode de paiement invalide')
];

// Créer un paiement
router.post('/', authenticateToken, paymentValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const { violationId, amount, paymentMethod, transactionId } = req.body;

    // Vérifier que la contravention existe et n'est pas déjà payée
    const violation = await db.query('SELECT * FROM violations WHERE id = ?', [violationId]);
    if (!violation.length) {
      return res.status(404).json({
        error: 'Contravention non trouvée',
        message: 'Aucune contravention trouvée avec cet ID'
      });
    }

    if (violation[0].status === 'paid') {
      return res.status(400).json({
        error: 'Contravention déjà payée',
        message: 'Cette contravention a déjà été payée'
      });
    }

    // Vérifier les permissions pour les citoyens
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length && citizen[0].id !== violation[0].citizen_id) {
        return res.status(403).json({
          error: 'Accès refusé',
          message: 'Vous ne pouvez payer que vos propres contraventions'
        });
      }
    }

    // Vérifier que le montant correspond
    if (amount !== violation[0].fine) {
      return res.status(400).json({
        error: 'Montant incorrect',
        message: `Le montant doit être de ${violation[0].fine} FCFA`
      });
    }

    const paymentId = uuidv4();
    const receiptNumber = `FP-${Date.now()}-${Math.random().toString(36).substr(2, 6).toUpperCase()}`;

    // Créer le paiement
    await db.run(
      `INSERT INTO payments (
        id, violation_id, citizen_id, amount, payment_method, receipt_number, 
        status, transaction_id
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        paymentId, violationId, violation[0].citizen_id, amount, paymentMethod,
        receiptNumber, paymentMethod === 'cash' ? 'pending' : 'completed', transactionId || null
      ]
    );

    // Mettre à jour le statut de la contravention si le paiement est complété
    if (paymentMethod !== 'cash') {
      await db.run(
        'UPDATE violations SET status = "paid", payment_date = CURRENT_DATE WHERE id = ?',
        [violationId]
      );
    }

    const payment = await db.query('SELECT * FROM payments WHERE id = ?', [paymentId]);

    res.status(201).json({
      message: paymentMethod === 'cash' 
        ? 'Paiement enregistré, veuillez vous rendre au commissariat' 
        : 'Paiement effectué avec succès',
      payment: payment[0]
    });

  } catch (error) {
    console.error('Erreur création paiement:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de traiter le paiement'
    });
  }
});

// Obtenir tous les paiements
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { status, paymentMethod, citizenId, limit = 50, offset = 0 } = req.query;
    
    let query = `
      SELECT p.*, v.type as violation_type, v.description as violation_description
      FROM payments p
      JOIN violations v ON p.violation_id = v.id
      WHERE 1=1
    `;
    let params = [];

    // Si c'est un citoyen, ne montrer que ses paiements
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND p.citizen_id = ?';
        params.push(citizen[0].id);
      }
    }

    if (status) {
      query += ' AND p.status = ?';
      params.push(status);
    }

    if (paymentMethod) {
      query += ' AND p.payment_method = ?';
      params.push(paymentMethod);
    }

    if (citizenId && req.user.role !== 'citizen') {
      query += ' AND p.citizen_id = ?';
      params.push(citizenId);
    }

    query += ' ORDER BY p.payment_date DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const payments = await db.query(query, params);

    res.json({ payments });

  } catch (error) {
    console.error('Erreur récupération paiements:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les paiements'
    });
  }
});

// Obtenir un paiement par ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    let query = `
      SELECT p.*, v.type as violation_type, v.description as violation_description,
             c.first_name, c.last_name
      FROM payments p
      JOIN violations v ON p.violation_id = v.id
      JOIN citizens c ON p.citizen_id = c.id
      WHERE p.id = ?
    `;
    let params = [id];

    // Vérifier les permissions pour les citoyens
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND p.citizen_id = ?';
        params.push(citizen[0].id);
      }
    }

    const payments = await db.query(query, params);
    
    if (!payments.length) {
      return res.status(404).json({
        error: 'Paiement non trouvé',
        message: 'Aucun paiement trouvé avec cet ID'
      });
    }

    res.json({ payment: payments[0] });

  } catch (error) {
    console.error('Erreur récupération paiement:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer le paiement'
    });
  }
});

// Confirmer un paiement en espèces
router.patch('/:id/confirm', authenticateToken, authorizeRoles('admin', 'police'), logActivity, async (req, res) => {
  try {
    const { id } = req.params;

    const payments = await db.query('SELECT * FROM payments WHERE id = ?', [id]);
    if (!payments.length) {
      return res.status(404).json({
        error: 'Paiement non trouvé',
        message: 'Aucun paiement trouvé avec cet ID'
      });
    }

    const payment = payments[0];

    if (payment.status === 'completed') {
      return res.status(400).json({
        error: 'Paiement déjà confirmé',
        message: 'Ce paiement a déjà été confirmé'
      });
    }

    // Mettre à jour le paiement
    await db.run(
      'UPDATE payments SET status = "completed", updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [id]
    );

    // Mettre à jour la contravention
    await db.run(
      'UPDATE violations SET status = "paid", payment_date = CURRENT_DATE WHERE id = ?',
      [payment.violation_id]
    );

    const updatedPayment = await db.query('SELECT * FROM payments WHERE id = ?', [id]);

    res.json({
      message: 'Paiement confirmé avec succès',
      payment: updatedPayment[0]
    });

  } catch (error) {
    console.error('Erreur confirmation paiement:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de confirmer le paiement'
    });
  }
});

// Obtenir le reçu d'un paiement
router.get('/:id/receipt', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    let query = `
      SELECT p.*, v.type as violation_type, v.description as violation_description,
             v.date as violation_date, v.location as violation_location,
             c.first_name, c.last_name, c.national_id
      FROM payments p
      JOIN violations v ON p.violation_id = v.id
      JOIN citizens c ON p.citizen_id = c.id
      WHERE p.id = ? AND p.status = 'completed'
    `;
    let params = [id];

    // Vérifier les permissions pour les citoyens
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND p.citizen_id = ?';
        params.push(citizen[0].id);
      }
    }

    const payments = await db.query(query, params);
    
    if (!payments.length) {
      return res.status(404).json({
        error: 'Reçu non trouvé',
        message: 'Aucun reçu trouvé pour ce paiement'
      });
    }

    const payment = payments[0];

    // Générer le reçu
    const receipt = {
      receiptNumber: payment.receipt_number,
      paymentDate: payment.payment_date,
      citizen: {
        name: `${payment.first_name} ${payment.last_name}`,
        nationalId: payment.national_id
      },
      violation: {
        type: payment.violation_type,
        description: payment.violation_description,
        date: payment.violation_date,
        location: payment.violation_location
      },
      payment: {
        amount: payment.amount,
        method: payment.payment_method,
        transactionId: payment.transaction_id
      },
      issuer: 'République du Burkina Faso - Forces de l\'Ordre'
    };

    res.json({ receipt });

  } catch (error) {
    console.error('Erreur génération reçu:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de générer le reçu'
    });
  }
});

// Statistiques des paiements
router.get('/stats/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      db.query('SELECT COUNT(*) as total FROM payments'),
      db.query('SELECT COUNT(*) as completed FROM payments WHERE status = "completed"'),
      db.query('SELECT COUNT(*) as pending FROM payments WHERE status = "pending"'),
      db.query('SELECT SUM(amount) as total_amount FROM payments WHERE status = "completed"'),
      db.query('SELECT COUNT(*) as mobile_money FROM payments WHERE payment_method = "mobile_money"'),
      db.query('SELECT COUNT(*) as cash FROM payments WHERE payment_method = "cash"'),
      db.query('SELECT COUNT(*) as bank_transfer FROM payments WHERE payment_method = "bank_transfer"'),
      db.query('SELECT SUM(amount) as recent_amount FROM payments WHERE status = "completed" AND payment_date >= date("now", "-30 days")')
    ]);

    res.json({
      total: stats[0][0].total,
      completed: stats[1][0].completed,
      pending: stats[2][0].pending,
      totalAmount: stats[3][0].total_amount || 0,
      mobileMoney: stats[4][0].mobile_money,
      cash: stats[5][0].cash,
      bankTransfer: stats[6][0].bank_transfer,
      recentAmount: stats[7][0].recent_amount || 0
    });

  } catch (error) {
    console.error('Erreur statistiques paiements:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

module.exports = router;