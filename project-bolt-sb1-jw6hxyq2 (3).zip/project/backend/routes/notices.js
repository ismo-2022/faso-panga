const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticateToken, authorizeRoles, logActivity } = require('../middleware/auth');

const router = express.Router();

// Validation rules
const noticeValidation = [
  body('type').isIn(['person', 'vehicle']).withMessage('Type invalide (person ou vehicle)'),
  body('title').trim().isLength({ min: 10 }).withMessage('Le titre doit contenir au moins 10 caractères'),
  body('description').trim().isLength({ min: 20 }).withMessage('La description doit contenir au moins 20 caractères'),
  body('priority').isIn(['low', 'medium', 'high']).withMessage('Priorité invalide'),
  body('contactInfo').trim().isLength({ min: 8 }).withMessage('Informations de contact requises')
];

// Créer un avis de recherche
router.post('/', authenticateToken, authorizeRoles('admin', 'police'), noticeValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const {
      type, title, description, priority, reward, contactInfo,
      targetName, targetId, physicalDescription, lastLocation,
      vehiclePlate, vehicleMake, vehicleModel, vehicleColor
    } = req.body;

    // Construire les détails de la cible
    let targetDetails = {};
    
    if (type === 'person') {
      targetDetails = {
        name: targetName || null,
        nationalId: targetId || null,
        physicalDescription: physicalDescription || null,
        lastSeenLocation: lastLocation || null
      };
    } else {
      targetDetails = {
        licensePlate: vehiclePlate || null,
        make: vehicleMake || null,
        model: vehicleModel || null,
        color: vehicleColor || null,
        lastSeenLocation: lastLocation || null
      };
    }

    const noticeId = uuidv4();

    await db.run(
      `INSERT INTO search_notices (
        id, type, title, description, target_details, issued_by, priority, reward, contact_info
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        noticeId, type, title, description, JSON.stringify(targetDetails),
        req.user.id, priority, reward || null, contactInfo
      ]
    );

    const notice = await db.query('SELECT * FROM search_notices WHERE id = ?', [noticeId]);

    res.status(201).json({
      message: 'Avis de recherche créé avec succès',
      notice: {
        ...notice[0],
        target_details: JSON.parse(notice[0].target_details)
      }
    });

  } catch (error) {
    console.error('Erreur création avis:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de créer l\'avis de recherche'
    });
  }
});

// Obtenir tous les avis de recherche
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { status, type, priority, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM search_notices WHERE 1=1';
    let params = [];

    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }

    if (type) {
      query += ' AND type = ?';
      params.push(type);
    }

    if (priority) {
      query += ' AND priority = ?';
      params.push(priority);
    }

    query += ' ORDER BY priority DESC, issue_date DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const notices = await db.query(query, params);

    // Parser les détails JSON
    const parsedNotices = notices.map(notice => ({
      ...notice,
      target_details: JSON.parse(notice.target_details)
    }));

    res.json({ notices: parsedNotices });

  } catch (error) {
    console.error('Erreur récupération avis:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les avis de recherche'
    });
  }
});

// Obtenir un avis de recherche par ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    const notices = await db.query('SELECT * FROM search_notices WHERE id = ?', [id]);
    
    if (!notices.length) {
      return res.status(404).json({
        error: 'Avis non trouvé',
        message: 'Aucun avis de recherche trouvé avec cet ID'
      });
    }

    const notice = {
      ...notices[0],
      target_details: JSON.parse(notices[0].target_details)
    };

    res.json({ notice });

  } catch (error) {
    console.error('Erreur récupération avis:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer l\'avis de recherche'
    });
  }
});

// Mettre à jour un avis de recherche
router.put('/:id', authenticateToken, authorizeRoles('admin', 'police'), noticeValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const { id } = req.params;
    const {
      title, description, priority, reward, contactInfo,
      targetName, targetId, physicalDescription, lastLocation,
      vehiclePlate, vehicleMake, vehicleModel, vehicleColor
    } = req.body;

    // Vérifier que l'avis existe et appartient à l'utilisateur (sauf admin)
    let checkQuery = 'SELECT * FROM search_notices WHERE id = ?';
    let checkParams = [id];

    if (req.user.role === 'police') {
      checkQuery += ' AND issued_by = ?';
      checkParams.push(req.user.id);
    }

    const existingNotices = await db.query(checkQuery, checkParams);
    if (!existingNotices.length) {
      return res.status(404).json({
        error: 'Avis non trouvé',
        message: 'Aucun avis de recherche trouvé avec cet ID'
      });
    }

    const existingNotice = existingNotices[0];
    const existingDetails = JSON.parse(existingNotice.target_details);

    // Construire les nouveaux détails
    let targetDetails = {};
    
    if (existingNotice.type === 'person') {
      targetDetails = {
        name: targetName !== undefined ? targetName : existingDetails.name,
        nationalId: targetId !== undefined ? targetId : existingDetails.nationalId,
        physicalDescription: physicalDescription !== undefined ? physicalDescription : existingDetails.physicalDescription,
        lastSeenLocation: lastLocation !== undefined ? lastLocation : existingDetails.lastSeenLocation
      };
    } else {
      targetDetails = {
        licensePlate: vehiclePlate !== undefined ? vehiclePlate : existingDetails.licensePlate,
        make: vehicleMake !== undefined ? vehicleMake : existingDetails.make,
        model: vehicleModel !== undefined ? vehicleModel : existingDetails.model,
        color: vehicleColor !== undefined ? vehicleColor : existingDetails.color,
        lastSeenLocation: lastLocation !== undefined ? lastLocation : existingDetails.lastSeenLocation
      };
    }

    await db.run(
      `UPDATE search_notices SET 
        title = ?, description = ?, target_details = ?, priority = ?, reward = ?, 
        contact_info = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [title, description, JSON.stringify(targetDetails), priority, reward, contactInfo, id]
    );

    const updatedNotice = await db.query('SELECT * FROM search_notices WHERE id = ?', [id]);

    res.json({
      message: 'Avis de recherche mis à jour avec succès',
      notice: {
        ...updatedNotice[0],
        target_details: JSON.parse(updatedNotice[0].target_details)
      }
    });

  } catch (error) {
    console.error('Erreur mise à jour avis:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de mettre à jour l\'avis de recherche'
    });
  }
});

// Mettre à jour le statut d'un avis
router.patch('/:id/status', authenticateToken, authorizeRoles('admin', 'police'), logActivity, async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['active', 'resolved', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: 'Statut invalide',
        message: 'Le statut doit être: active, resolved ou cancelled'
      });
    }

    // Vérifier les permissions
    let query = 'SELECT * FROM search_notices WHERE id = ?';
    let params = [id];

    if (req.user.role === 'police') {
      query += ' AND issued_by = ?';
      params.push(req.user.id);
    }

    const notices = await db.query(query, params);
    if (!notices.length) {
      return res.status(404).json({
        error: 'Avis non trouvé',
        message: 'Aucun avis de recherche trouvé avec cet ID'
      });
    }

    await db.run(
      'UPDATE search_notices SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [status, id]
    );

    const updatedNotice = await db.query('SELECT * FROM search_notices WHERE id = ?', [id]);

    res.json({
      message: 'Statut mis à jour avec succès',
      notice: {
        ...updatedNotice[0],
        target_details: JSON.parse(updatedNotice[0].target_details)
      }
    });

  } catch (error) {
    console.error('Erreur mise à jour statut avis:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de mettre à jour le statut'
    });
  }
});

// Obtenir les avis actifs par priorité
router.get('/active/priority/:priority', authenticateToken, async (req, res) => {
  try {
    const { priority } = req.params;

    if (!['low', 'medium', 'high'].includes(priority)) {
      return res.status(400).json({
        error: 'Priorité invalide',
        message: 'La priorité doit être: low, medium ou high'
      });
    }

    const notices = await db.query(
      'SELECT * FROM search_notices WHERE status = "active" AND priority = ? ORDER BY issue_date DESC',
      [priority]
    );

    const parsedNotices = notices.map(notice => ({
      ...notice,
      target_details: JSON.parse(notice.target_details)
    }));

    res.json({ notices: parsedNotices });

  } catch (error) {
    console.error('Erreur récupération avis par priorité:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les avis de recherche'
    });
  }
});

// Statistiques des avis de recherche
router.get('/stats/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      db.query('SELECT COUNT(*) as total FROM search_notices'),
      db.query('SELECT COUNT(*) as active FROM search_notices WHERE status = "active"'),
      db.query('SELECT COUNT(*) as resolved FROM search_notices WHERE status = "resolved"'),
      db.query('SELECT COUNT(*) as cancelled FROM search_notices WHERE status = "cancelled"'),
      db.query('SELECT COUNT(*) as high_priority FROM search_notices WHERE priority = "high" AND status = "active"'),
      db.query('SELECT COUNT(*) as person_type FROM search_notices WHERE type = "person"'),
      db.query('SELECT COUNT(*) as vehicle_type FROM search_notices WHERE type = "vehicle"')
    ]);

    res.json({
      total: stats[0][0].total,
      active: stats[1][0].active,
      resolved: stats[2][0].resolved,
      cancelled: stats[3][0].cancelled,
      highPriority: stats[4][0].high_priority,
      personType: stats[5][0].person_type,
      vehicleType: stats[6][0].vehicle_type
    });

  } catch (error) {
    console.error('Erreur statistiques avis:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

module.exports = router;