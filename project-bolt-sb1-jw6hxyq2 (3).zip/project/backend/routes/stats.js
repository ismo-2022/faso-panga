const express = require('express');
const db = require('../config/database');
const { authenticateToken, authorizeRoles } = require('../middleware/auth');

const router = express.Router();

// Statistiques générales (Admin seulement)
router.get('/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      // Citoyens
      db.query('SELECT COUNT(*) as total FROM citizens WHERE is_active = 1'),
      db.query('SELECT COUNT(*) as recent_citizens FROM citizens WHERE created_at >= date("now", "-30 days")'),
      
      // Véhicules
      db.query('SELECT COUNT(*) as total FROM vehicles WHERE is_active = 1'),
      db.query('SELECT COUNT(*) as recent_vehicles FROM vehicles WHERE created_at >= date("now", "-30 days")'),
      
      // Contraventions
      db.query('SELECT COUNT(*) as total FROM violations'),
      db.query('SELECT COUNT(*) as pending_violations FROM violations WHERE status = "pending"'),
      db.query('SELECT SUM(fine) as total_fines FROM violations WHERE status = "paid"'),
      
      // Avis de recherche
      db.query('SELECT COUNT(*) as total FROM search_notices WHERE status = "active"'),
      db.query('SELECT COUNT(*) as high_priority_notices FROM search_notices WHERE status = "active" AND priority = "high"'),
      
      // Signalements
      db.query('SELECT COUNT(*) as total FROM reports'),
      db.query('SELECT COUNT(*) as pending_reports FROM reports WHERE status = "pending"'),
      
      // Paiements
      db.query('SELECT SUM(amount) as total_payments FROM payments WHERE status = "completed"'),
      db.query('SELECT SUM(amount) as recent_payments FROM payments WHERE status = "completed" AND payment_date >= date("now", "-30 days")')
    ]);

    res.json({
      citizens: {
        total: stats[0][0].total,
        recent: stats[1][0].recent_citizens
      },
      vehicles: {
        total: stats[2][0].total,
        recent: stats[3][0].recent_vehicles
      },
      violations: {
        total: stats[4][0].total,
        pending: stats[5][0].pending_violations,
        totalFines: stats[6][0].total_fines || 0
      },
      notices: {
        active: stats[7][0].total,
        highPriority: stats[8][0].high_priority_notices
      },
      reports: {
        total: stats[9][0].total,
        pending: stats[10][0].pending_reports
      },
      payments: {
        total: stats[11][0].total_payments || 0,
        recent: stats[12][0].recent_payments || 0
      }
    });

  } catch (error) {
    console.error('Erreur statistiques générales:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

// Statistiques par période
router.get('/period/:period', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const { period } = req.params;
    
    let dateFilter = '';
    switch (period) {
      case 'week':
        dateFilter = 'date("now", "-7 days")';
        break;
      case 'month':
        dateFilter = 'date("now", "-30 days")';
        break;
      case 'quarter':
        dateFilter = 'date("now", "-90 days")';
        break;
      case 'year':
        dateFilter = 'date("now", "-365 days")';
        break;
      default:
        return res.status(400).json({
          error: 'Période invalide',
          message: 'La période doit être: week, month, quarter ou year'
        });
    }

    const stats = await Promise.all([
      db.query(`SELECT COUNT(*) as count FROM citizens WHERE created_at >= ${dateFilter}`),
      db.query(`SELECT COUNT(*) as count FROM vehicles WHERE created_at >= ${dateFilter}`),
      db.query(`SELECT COUNT(*) as count FROM violations WHERE created_at >= ${dateFilter}`),
      db.query(`SELECT COUNT(*) as count FROM reports WHERE created_at >= ${dateFilter}`),
      db.query(`SELECT SUM(amount) as total FROM payments WHERE status = "completed" AND payment_date >= ${dateFilter}`)
    ]);

    res.json({
      period,
      citizens: stats[0][0].count,
      vehicles: stats[1][0].count,
      violations: stats[2][0].count,
      reports: stats[3][0].count,
      payments: stats[4][0].total || 0
    });

  } catch (error) {
    console.error('Erreur statistiques par période:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

// Statistiques des contraventions par type
router.get('/violations/types', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await db.query(`
      SELECT type, COUNT(*) as count, SUM(fine) as total_fines
      FROM violations 
      GROUP BY type 
      ORDER BY count DESC
    `);

    res.json({ violationTypes: stats });

  } catch (error) {
    console.error('Erreur statistiques types contraventions:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

// Statistiques des officiers
router.get('/officers/performance', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await db.query(`
      SELECT 
        officer_id,
        officer_name,
        COUNT(*) as total_violations,
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as paid_violations,
        SUM(CASE WHEN status = 'contested' THEN 1 ELSE 0 END) as contested_violations,
        SUM(fine) as total_fines,
        SUM(CASE WHEN status = 'paid' THEN fine ELSE 0 END) as collected_fines
      FROM violations 
      GROUP BY officer_id, officer_name 
      ORDER BY total_violations DESC
    `);

    res.json({ officerPerformance: stats });

  } catch (error) {
    console.error('Erreur statistiques performance officiers:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

// Statistiques géographiques
router.get('/geographic/violations', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await db.query(`
      SELECT 
        location,
        COUNT(*) as count,
        SUM(fine) as total_fines
      FROM violations 
      GROUP BY location 
      ORDER BY count DESC
      LIMIT 20
    `);

    res.json({ geographicStats: stats });

  } catch (error) {
    console.error('Erreur statistiques géographiques:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

// Évolution mensuelle
router.get('/trends/monthly', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const trends = await Promise.all([
      // Contraventions par mois
      db.query(`
        SELECT 
          strftime('%Y-%m', date) as month,
          COUNT(*) as violations,
          SUM(fine) as fines
        FROM violations 
        WHERE date >= date('now', '-12 months')
        GROUP BY strftime('%Y-%m', date)
        ORDER BY month
      `),
      
      // Enregistrements citoyens par mois
      db.query(`
        SELECT 
          strftime('%Y-%m', created_at) as month,
          COUNT(*) as citizens
        FROM citizens 
        WHERE created_at >= date('now', '-12 months')
        GROUP BY strftime('%Y-%m', created_at)
        ORDER BY month
      `),
      
      // Paiements par mois
      db.query(`
        SELECT 
          strftime('%Y-%m', payment_date) as month,
          COUNT(*) as payments,
          SUM(amount) as amount
        FROM payments 
        WHERE status = 'completed' AND payment_date >= date('now', '-12 months')
        GROUP BY strftime('%Y-%m', payment_date)
        ORDER BY month
      `)
    ]);

    res.json({
      violations: trends[0],
      citizens: trends[1],
      payments: trends[2]
    });

  } catch (error) {
    console.error('Erreur tendances mensuelles:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les tendances'
    });
  }
});

// Alertes système
router.get('/alerts', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const alerts = await Promise.all([
      // Véhicules avec assurance expirée
      db.query(`
        SELECT COUNT(*) as count 
        FROM vehicles 
        WHERE is_active = 1 AND insurance_expiry < date('now')
      `),
      
      // Véhicules avec contrôle technique expiré
      db.query(`
        SELECT COUNT(*) as count 
        FROM vehicles 
        WHERE is_active = 1 AND technical_control_expiry < date('now')
      `),
      
      // Contraventions en attente depuis plus de 30 jours
      db.query(`
        SELECT COUNT(*) as count 
        FROM violations 
        WHERE status = 'pending' AND date < date('now', '-30 days')
      `),
      
      // Avis de recherche haute priorité actifs
      db.query(`
        SELECT COUNT(*) as count 
        FROM search_notices 
        WHERE status = 'active' AND priority = 'high'
      `),
      
      // Signalements en attente
      db.query(`
        SELECT COUNT(*) as count 
        FROM reports 
        WHERE status = 'pending'
      `)
    ]);

    res.json({
      expiredInsurance: alerts[0][0].count,
      expiredTechnical: alerts[1][0].count,
      oldViolations: alerts[2][0].count,
      highPriorityNotices: alerts[3][0].count,
      pendingReports: alerts[4][0].count
    });

  } catch (error) {
    console.error('Erreur alertes système:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les alertes'
    });
  }
});

// Statistiques personnelles pour les officiers
router.get('/personal', authenticateToken, authorizeRoles('police'), async (req, res) => {
  try {
    const stats = await Promise.all([
      // Contraventions créées par l'officier
      db.query('SELECT COUNT(*) as total FROM violations WHERE officer_id = ?', [req.user.id]),
      db.query('SELECT COUNT(*) as paid FROM violations WHERE officer_id = ? AND status = "paid"', [req.user.id]),
      db.query('SELECT COUNT(*) as contested FROM violations WHERE officer_id = ? AND status = "contested"', [req.user.id]),
      db.query('SELECT SUM(fine) as total_fines FROM violations WHERE officer_id = ?', [req.user.id]),
      
      // Statistiques du mois en cours
      db.query(`
        SELECT COUNT(*) as monthly_violations 
        FROM violations 
        WHERE officer_id = ? AND strftime('%Y-%m', created_at) = strftime('%Y-%m', 'now')
      `, [req.user.id])
    ]);

    res.json({
      totalViolations: stats[0][0].total,
      paidViolations: stats[1][0].paid,
      contestedViolations: stats[2][0].contested,
      totalFines: stats[3][0].total_fines || 0,
      monthlyViolations: stats[4][0].monthly_violations
    });

  } catch (error) {
    console.error('Erreur statistiques personnelles:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques personnelles'
    });
  }
});

module.exports = router;