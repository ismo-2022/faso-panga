const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticateToken, authorizeRoles, logActivity } = require('../middleware/auth');

const router = express.Router();

// Validation rules
const citizenValidation = [
  body('firstName').trim().isLength({ min: 2 }).withMessage('Le prénom doit contenir au moins 2 caractères'),
  body('lastName').trim().isLength({ min: 2 }).withMessage('Le nom doit contenir au moins 2 caractères'),
  body('nationalId').trim().isLength({ min: 8 }).withMessage('Le numéro CNI doit contenir au moins 8 caractères'),
  body('phone').trim().isLength({ min: 8 }).withMessage('Le numéro de téléphone doit contenir au moins 8 caractères'),
  body('address').trim().isLength({ min: 10 }).withMessage('L\'adresse doit contenir au moins 10 caractères'),
  body('dateOfBirth').isISO8601().withMessage('Date de naissance invalide')
];

// Créer un citoyen
router.post('/', citizenValidation, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const {
      firstName, lastName, dateOfBirth, nationalId, phone, email,
      address, profession, emergencyContact, emergencyPhone, userId
    } = req.body;

    // Vérifier si le CNI existe déjà
    const existingCitizen = await db.query('SELECT id FROM citizens WHERE national_id = ?', [nationalId]);
    if (existingCitizen.length > 0) {
      return res.status(409).json({
        error: 'CNI déjà enregistrée',
        message: 'Un citoyen avec ce numéro CNI existe déjà'
      });
    }

    const citizenId = uuidv4();

    await db.run(
      `INSERT INTO citizens (
        id, user_id, first_name, last_name, date_of_birth, national_id,
        phone, email, address, profession, emergency_contact, emergency_phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        citizenId, userId || null, firstName, lastName, dateOfBirth, nationalId,
        phone, email || null, address, profession || null, emergencyContact || null, emergencyPhone || null
      ]
    );

    const citizen = await db.query('SELECT * FROM citizens WHERE id = ?', [citizenId]);

    res.status(201).json({
      message: 'Citoyen enregistré avec succès',
      citizen: citizen[0]
    });

  } catch (error) {
    console.error('Erreur création citoyen:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible d\'enregistrer le citoyen'
    });
  }
});

// Obtenir tous les citoyens (Admin/Police)
router.get('/', authenticateToken, authorizeRoles('admin', 'police'), async (req, res) => {
  try {
    const { search, status, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM citizens WHERE 1=1';
    let params = [];

    if (search) {
      query += ' AND (first_name LIKE ? OR last_name LIKE ? OR national_id LIKE ? OR phone LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    if (status !== undefined) {
      query += ' AND is_active = ?';
      params.push(status === 'active' ? 1 : 0);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const citizens = await db.query(query, params);

    // Compter le total
    let countQuery = 'SELECT COUNT(*) as total FROM citizens WHERE 1=1';
    let countParams = [];

    if (search) {
      countQuery += ' AND (first_name LIKE ? OR last_name LIKE ? OR national_id LIKE ? OR phone LIKE ?)';
      const searchTerm = `%${search}%`;
      countParams.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    if (status !== undefined) {
      countQuery += ' AND is_active = ?';
      countParams.push(status === 'active' ? 1 : 0);
    }

    const countResult = await db.query(countQuery, countParams);

    res.json({
      citizens,
      total: countResult[0].total,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });

  } catch (error) {
    console.error('Erreur récupération citoyens:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les citoyens'
    });
  }
});

// Obtenir un citoyen par ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    // Vérifier les permissions
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (!citizen.length || citizen[0].id !== id) {
        return res.status(403).json({
          error: 'Accès refusé',
          message: 'Vous ne pouvez consulter que vos propres informations'
        });
      }
    }

    const citizens = await db.query('SELECT * FROM citizens WHERE id = ?', [id]);
    
    if (!citizens.length) {
      return res.status(404).json({
        error: 'Citoyen non trouvé',
        message: 'Aucun citoyen trouvé avec cet ID'
      });
    }

    res.json({ citizen: citizens[0] });

  } catch (error) {
    console.error('Erreur récupération citoyen:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer le citoyen'
    });
  }
});

// Rechercher un citoyen par CNI ou nom
router.get('/search/:term', authenticateToken, authorizeRoles('admin', 'police'), async (req, res) => {
  try {
    const { term } = req.params;

    const citizens = await db.query(
      `SELECT * FROM citizens 
       WHERE national_id LIKE ? OR first_name LIKE ? OR last_name LIKE ? OR phone LIKE ?
       AND is_active = 1
       LIMIT 10`,
      [`%${term}%`, `%${term}%`, `%${term}%`, `%${term}%`]
    );

    res.json({ citizens });

  } catch (error) {
    console.error('Erreur recherche citoyen:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de rechercher le citoyen'
    });
  }
});

// Mettre à jour un citoyen
router.put('/:id', authenticateToken, citizenValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const { id } = req.params;
    const {
      firstName, lastName, dateOfBirth, phone, email,
      address, profession, emergencyContact, emergencyPhone
    } = req.body;

    // Vérifier les permissions
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (!citizen.length || citizen[0].id !== id) {
        return res.status(403).json({
          error: 'Accès refusé',
          message: 'Vous ne pouvez modifier que vos propres informations'
        });
      }
    }

    const result = await db.run(
      `UPDATE citizens SET 
        first_name = ?, last_name = ?, date_of_birth = ?, phone = ?, email = ?,
        address = ?, profession = ?, emergency_contact = ?, emergency_phone = ?,
        updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [firstName, lastName, dateOfBirth, phone, email, address, profession, emergencyContact, emergencyPhone, id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Citoyen non trouvé',
        message: 'Aucun citoyen trouvé avec cet ID'
      });
    }

    const updatedCitizen = await db.query('SELECT * FROM citizens WHERE id = ?', [id]);

    res.json({
      message: 'Citoyen mis à jour avec succès',
      citizen: updatedCitizen[0]
    });

  } catch (error) {
    console.error('Erreur mise à jour citoyen:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de mettre à jour le citoyen'
    });
  }
});

// Désactiver un citoyen (Admin seulement)
router.patch('/:id/deactivate', authenticateToken, authorizeRoles('admin'), logActivity, async (req, res) => {
  try {
    const { id } = req.params;

    const result = await db.run(
      'UPDATE citizens SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Citoyen non trouvé',
        message: 'Aucun citoyen trouvé avec cet ID'
      });
    }

    res.json({
      message: 'Citoyen désactivé avec succès'
    });

  } catch (error) {
    console.error('Erreur désactivation citoyen:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de désactiver le citoyen'
    });
  }
});

// Statistiques des citoyens (Admin)
router.get('/stats/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      db.query('SELECT COUNT(*) as total FROM citizens'),
      db.query('SELECT COUNT(*) as active FROM citizens WHERE is_active = 1'),
      db.query('SELECT COUNT(*) as inactive FROM citizens WHERE is_active = 0'),
      db.query('SELECT COUNT(*) as recent FROM citizens WHERE created_at >= date("now", "-30 days")')
    ]);

    res.json({
      total: stats[0][0].total,
      active: stats[1][0].active,
      inactive: stats[2][0].inactive,
      recentRegistrations: stats[3][0].recent
    });

  } catch (error) {
    console.error('Erreur statistiques citoyens:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

module.exports = router;