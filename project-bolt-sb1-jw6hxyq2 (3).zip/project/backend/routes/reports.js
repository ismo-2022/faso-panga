const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticateToken, authorizeRoles, logActivity } = require('../middleware/auth');

const router = express.Router();

// Validation rules
const reportValidation = [
  body('type').isIn(['theft', 'accident', 'suspicious', 'other']).withMessage('Type de signalement invalide'),
  body('title').trim().isLength({ min: 5 }).withMessage('Le titre doit contenir au moins 5 caractères'),
  body('description').trim().isLength({ min: 20 }).withMessage('La description doit contenir au moins 20 caractères'),
  body('location').trim().isLength({ min: 5 }).withMessage('Le lieu doit contenir au moins 5 caractères')
];

// Créer un signalement
router.post('/', authenticateToken, reportValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const { type, title, description, location, priority = 'medium' } = req.body;

    // Récupérer les informations du citoyen
    let citizenId = null;
    let citizenName = 'Anonyme';

    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id, first_name, last_name FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        citizenId = citizen[0].id;
        citizenName = `${citizen[0].first_name} ${citizen[0].last_name}`;
      }
    } else {
      // Si c'est un admin ou police qui crée un signalement au nom d'un citoyen
      if (req.body.citizenId) {
        const citizen = await db.query('SELECT id, first_name, last_name FROM citizens WHERE id = ?', [req.body.citizenId]);
        if (citizen.length) {
          citizenId = citizen[0].id;
          citizenName = `${citizen[0].first_name} ${citizen[0].last_name}`;
        }
      }
    }

    const reportId = uuidv4();

    await db.run(
      `INSERT INTO reports (
        id, citizen_id, citizen_name, type, title, description, location, priority
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [reportId, citizenId, citizenName, type, title, description, location, priority]
    );

    const report = await db.query('SELECT * FROM reports WHERE id = ?', [reportId]);

    res.status(201).json({
      message: 'Signalement créé avec succès',
      report: report[0]
    });

  } catch (error) {
    console.error('Erreur création signalement:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de créer le signalement'
    });
  }
});

// Obtenir tous les signalements
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { status, type, priority, citizenId, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM reports WHERE 1=1';
    let params = [];

    // Si c'est un citoyen, ne montrer que ses signalements
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND citizen_id = ?';
        params.push(citizen[0].id);
      }
    }

    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }

    if (type) {
      query += ' AND type = ?';
      params.push(type);
    }

    if (priority) {
      query += ' AND priority = ?';
      params.push(priority);
    }

    if (citizenId && req.user.role !== 'citizen') {
      query += ' AND citizen_id = ?';
      params.push(citizenId);
    }

    query += ' ORDER BY priority DESC, date DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const reports = await db.query(query, params);

    res.json({ reports });

  } catch (error) {
    console.error('Erreur récupération signalements:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les signalements'
    });
  }
});

// Obtenir un signalement par ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    let query = 'SELECT * FROM reports WHERE id = ?';
    let params = [id];

    // Vérifier les permissions pour les citoyens
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND citizen_id = ?';
        params.push(citizen[0].id);
      }
    }

    const reports = await db.query(query, params);
    
    if (!reports.length) {
      return res.status(404).json({
        error: 'Signalement non trouvé',
        message: 'Aucun signalement trouvé avec cet ID'
      });
    }

    res.json({ report: reports[0] });

  } catch (error) {
    console.error('Erreur récupération signalement:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer le signalement'
    });
  }
});

// Mettre à jour le statut d'un signalement
router.patch('/:id/status', authenticateToken, authorizeRoles('admin', 'police'), logActivity, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, assignedOfficer } = req.body;

    const validStatuses = ['pending', 'investigating', 'resolved', 'closed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: 'Statut invalide',
        message: 'Le statut doit être: pending, investigating, resolved ou closed'
      });
    }

    const reports = await db.query('SELECT * FROM reports WHERE id = ?', [id]);
    if (!reports.length) {
      return res.status(404).json({
        error: 'Signalement non trouvé',
        message: 'Aucun signalement trouvé avec cet ID'
      });
    }

    let updateQuery = 'UPDATE reports SET status = ?, updated_at = CURRENT_TIMESTAMP';
    let updateParams = [status];

    if (assignedOfficer) {
      updateQuery += ', assigned_officer = ?';
      updateParams.push(assignedOfficer);
    }

    updateQuery += ' WHERE id = ?';
    updateParams.push(id);

    await db.run(updateQuery, updateParams);

    const updatedReport = await db.query('SELECT * FROM reports WHERE id = ?', [id]);

    res.json({
      message: 'Statut mis à jour avec succès',
      report: updatedReport[0]
    });

  } catch (error) {
    console.error('Erreur mise à jour statut signalement:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de mettre à jour le statut'
    });
  }
});

// Assigner un signalement à un officier
router.patch('/:id/assign', authenticateToken, authorizeRoles('admin'), logActivity, async (req, res) => {
  try {
    const { id } = req.params;
    const { officerId } = req.body;

    // Vérifier que l'officier existe
    const officer = await db.query('SELECT name FROM users WHERE id = ? AND role IN ("admin", "police")', [officerId]);
    if (!officer.length) {
      return res.status(404).json({
        error: 'Officier non trouvé',
        message: 'Aucun officier trouvé avec cet ID'
      });
    }

    const result = await db.run(
      'UPDATE reports SET assigned_officer = ?, status = "investigating", updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [officer[0].name, id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Signalement non trouvé',
        message: 'Aucun signalement trouvé avec cet ID'
      });
    }

    const updatedReport = await db.query('SELECT * FROM reports WHERE id = ?', [id]);

    res.json({
      message: 'Signalement assigné avec succès',
      report: updatedReport[0]
    });

  } catch (error) {
    console.error('Erreur assignation signalement:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible d\'assigner le signalement'
    });
  }
});

// Obtenir les signalements par priorité
router.get('/priority/:priority', authenticateToken, authorizeRoles('admin', 'police'), async (req, res) => {
  try {
    const { priority } = req.params;

    if (!['low', 'medium', 'high'].includes(priority)) {
      return res.status(400).json({
        error: 'Priorité invalide',
        message: 'La priorité doit être: low, medium ou high'
      });
    }

    const reports = await db.query(
      'SELECT * FROM reports WHERE priority = ? AND status IN ("pending", "investigating") ORDER BY date DESC',
      [priority]
    );

    res.json({ reports });

  } catch (error) {
    console.error('Erreur récupération signalements par priorité:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les signalements'
    });
  }
});

// Statistiques des signalements
router.get('/stats/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      db.query('SELECT COUNT(*) as total FROM reports'),
      db.query('SELECT COUNT(*) as pending FROM reports WHERE status = "pending"'),
      db.query('SELECT COUNT(*) as investigating FROM reports WHERE status = "investigating"'),
      db.query('SELECT COUNT(*) as resolved FROM reports WHERE status = "resolved"'),
      db.query('SELECT COUNT(*) as closed FROM reports WHERE status = "closed"'),
      db.query('SELECT COUNT(*) as high_priority FROM reports WHERE priority = "high" AND status IN ("pending", "investigating")'),
      db.query('SELECT COUNT(*) as recent FROM reports WHERE created_at >= date("now", "-7 days")')
    ]);

    // Statistiques par type
    const typeStats = await db.query(
      `SELECT type, COUNT(*) as count 
       FROM reports 
       GROUP BY type 
       ORDER BY count DESC`
    );

    res.json({
      total: stats[0][0].total,
      pending: stats[1][0].pending,
      investigating: stats[2][0].investigating,
      resolved: stats[3][0].resolved,
      closed: stats[4][0].closed,
      highPriority: stats[5][0].high_priority,
      recentReports: stats[6][0].recent,
      byType: typeStats
    });

  } catch (error) {
    console.error('Erreur statistiques signalements:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

module.exports = router;