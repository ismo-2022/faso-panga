const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticateToken, authorizeRoles, logActivity } = require('../middleware/auth');

const router = express.Router();

// Types de contraventions avec montants
const violationTypes = {
  'speeding': { label: 'Excès de vitesse', fine: 25000 },
  'parking': { label: 'Stationnement interdit', fine: 15000 },
  'red_light': { label: 'Feu rouge grillé', fine: 30000 },
  'phone': { label: 'Téléphone au volant', fine: 20000 },
  'seatbelt': { label: 'Ceinture de sécurité', fine: 10000 },
  'documents': { label: 'Défaut de documents', fine: 35000 },
  'drunk_driving': { label: 'Conduite en état d\'ivresse', fine: 100000 },
  'no_license': { label: 'Conduite sans permis', fine: 50000 },
  'other': { label: 'Autre', fine: 0 }
};

// Validation rules
const violationValidation = [
  body('citizenId').isUUID().withMessage('ID citoyen invalide'),
  body('type').isIn(Object.keys(violationTypes)).withMessage('Type de contravention invalide'),
  body('description').trim().isLength({ min: 10 }).withMessage('La description doit contenir au moins 10 caractères'),
  body('location').trim().isLength({ min: 5 }).withMessage('Le lieu doit contenir au moins 5 caractères'),
  body('fine').isFloat({ min: 0 }).withMessage('Le montant de l\'amende doit être positif')
];

// Créer une contravention
router.post('/', authenticateToken, authorizeRoles('admin', 'police'), violationValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const { citizenId, vehicleId, type, description, location, fine, date } = req.body;

    // Récupérer les informations du citoyen
    const citizen = await db.query('SELECT first_name, last_name FROM citizens WHERE id = ?', [citizenId]);
    if (!citizen.length) {
      return res.status(404).json({
        error: 'Citoyen non trouvé',
        message: 'Aucun citoyen trouvé avec cet ID'
      });
    }

    let vehiclePlate = null;
    if (vehicleId) {
      const vehicle = await db.query('SELECT license_plate FROM vehicles WHERE id = ?', [vehicleId]);
      if (vehicle.length) {
        vehiclePlate = vehicle[0].license_plate;
      }
    }

    const citizenName = `${citizen[0].first_name} ${citizen[0].last_name}`;
    const violationId = uuidv4();
    const violationType = violationTypes[type];

    await db.run(
      `INSERT INTO violations (
        id, citizen_id, citizen_name, vehicle_id, vehicle_plate, officer_id, officer_name,
        type, description, fine, date, location
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        violationId, citizenId, citizenName, vehicleId || null, vehiclePlate,
        req.user.id, req.user.name, violationType.label, description,
        fine || violationType.fine, date || new Date().toISOString().split('T')[0], location
      ]
    );

    const violation = await db.query('SELECT * FROM violations WHERE id = ?', [violationId]);

    res.status(201).json({
      message: 'Contravention créée avec succès',
      violation: violation[0]
    });

  } catch (error) {
    console.error('Erreur création contravention:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de créer la contravention'
    });
  }
});

// Obtenir toutes les contraventions
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { status, citizenId, officerId, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM violations WHERE 1=1';
    let params = [];

    // Si c'est un citoyen, ne montrer que ses contraventions
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND citizen_id = ?';
        params.push(citizen[0].id);
      }
    }

    // Si c'est un policier, ne montrer que ses contraventions (sauf admin)
    if (req.user.role === 'police') {
      query += ' AND officer_id = ?';
      params.push(req.user.id);
    }

    if (status) {
      query += ' AND status = ?';
      params.push(status);
    }

    if (citizenId) {
      query += ' AND citizen_id = ?';
      params.push(citizenId);
    }

    if (officerId && req.user.role === 'admin') {
      query += ' AND officer_id = ?';
      params.push(officerId);
    }

    query += ' ORDER BY date DESC, created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const violations = await db.query(query, params);

    res.json({ violations });

  } catch (error) {
    console.error('Erreur récupération contraventions:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les contraventions'
    });
  }
});

// Obtenir une contravention par ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    let query = 'SELECT * FROM violations WHERE id = ?';
    let params = [id];

    // Vérifier les permissions
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND citizen_id = ?';
        params.push(citizen[0].id);
      }
    } else if (req.user.role === 'police') {
      query += ' AND officer_id = ?';
      params.push(req.user.id);
    }

    const violations = await db.query(query, params);
    
    if (!violations.length) {
      return res.status(404).json({
        error: 'Contravention non trouvée',
        message: 'Aucune contravention trouvée avec cet ID'
      });
    }

    res.json({ violation: violations[0] });

  } catch (error) {
    console.error('Erreur récupération contravention:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer la contravention'
    });
  }
});

// Mettre à jour le statut d'une contravention
router.patch('/:id/status', authenticateToken, logActivity, async (req, res) => {
  try {
    const { id } = req.params;
    const { status, contestReason, paymentDate } = req.body;

    const validStatuses = ['pending', 'paid', 'contested', 'cancelled'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({
        error: 'Statut invalide',
        message: 'Le statut doit être: pending, paid, contested ou cancelled'
      });
    }

    // Vérifier les permissions
    let query = 'SELECT * FROM violations WHERE id = ?';
    let params = [id];

    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND citizen_id = ?';
        params.push(citizen[0].id);
      }
      // Les citoyens ne peuvent que contester
      if (status !== 'contested') {
        return res.status(403).json({
          error: 'Action non autorisée',
          message: 'Vous ne pouvez que contester une contravention'
        });
      }
    } else if (req.user.role === 'police') {
      query += ' AND officer_id = ?';
      params.push(req.user.id);
    }

    const violations = await db.query(query, params);
    if (!violations.length) {
      return res.status(404).json({
        error: 'Contravention non trouvée',
        message: 'Aucune contravention trouvée avec cet ID'
      });
    }

    let updateQuery = 'UPDATE violations SET status = ?, updated_at = CURRENT_TIMESTAMP';
    let updateParams = [status];

    if (status === 'contested' && contestReason) {
      updateQuery += ', contest_reason = ?';
      updateParams.push(contestReason);
    }

    if (status === 'paid' && paymentDate) {
      updateQuery += ', payment_date = ?';
      updateParams.push(paymentDate);
    }

    updateQuery += ' WHERE id = ?';
    updateParams.push(id);

    await db.run(updateQuery, updateParams);

    const updatedViolation = await db.query('SELECT * FROM violations WHERE id = ?', [id]);

    res.json({
      message: 'Statut mis à jour avec succès',
      violation: updatedViolation[0]
    });

  } catch (error) {
    console.error('Erreur mise à jour statut:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de mettre à jour le statut'
    });
  }
});

// Obtenir les types de contraventions disponibles
router.get('/types/list', authenticateToken, authorizeRoles('admin', 'police'), (req, res) => {
  res.json({ types: violationTypes });
});

// Statistiques des contraventions
router.get('/stats/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      db.query('SELECT COUNT(*) as total FROM violations'),
      db.query('SELECT COUNT(*) as pending FROM violations WHERE status = "pending"'),
      db.query('SELECT COUNT(*) as paid FROM violations WHERE status = "paid"'),
      db.query('SELECT COUNT(*) as contested FROM violations WHERE status = "contested"'),
      db.query('SELECT SUM(fine) as total_fines FROM violations'),
      db.query('SELECT SUM(fine) as paid_fines FROM violations WHERE status = "paid"'),
      db.query('SELECT COUNT(*) as recent FROM violations WHERE created_at >= date("now", "-30 days")')
    ]);

    res.json({
      total: stats[0][0].total,
      pending: stats[1][0].pending,
      paid: stats[2][0].paid,
      contested: stats[3][0].contested,
      totalFines: stats[4][0].total_fines || 0,
      paidFines: stats[5][0].paid_fines || 0,
      recentViolations: stats[6][0].recent
    });

  } catch (error) {
    console.error('Erreur statistiques contraventions:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

// Statistiques par officier
router.get('/stats/officers', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await db.query(
      `SELECT officer_id, officer_name, COUNT(*) as total_violations,
       SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as paid_violations,
       SUM(fine) as total_fines
       FROM violations 
       GROUP BY officer_id, officer_name 
       ORDER BY total_violations DESC`
    );

    res.json({ officerStats: stats });

  } catch (error) {
    console.error('Erreur statistiques officiers:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques par officier'
    });
  }
});

module.exports = router;