const express = require('express');
const { body, validationResult } = require('express-validator');
const { v4: uuidv4 } = require('uuid');
const db = require('../config/database');
const { authenticateToken, authorizeRoles, logActivity } = require('../middleware/auth');

const router = express.Router();

// Validation rules
const vehicleValidation = [
  body('make').trim().isLength({ min: 2 }).withMessage('La marque doit contenir au moins 2 caractères'),
  body('model').trim().isLength({ min: 2 }).withMessage('Le modèle doit contenir au moins 2 caractères'),
  body('year').isInt({ min: 1900, max: new Date().getFullYear() + 1 }).withMessage('Année invalide'),
  body('licensePlate').trim().isLength({ min: 5 }).withMessage('La plaque d\'immatriculation doit contenir au moins 5 caractères'),
  body('color').trim().isLength({ min: 3 }).withMessage('La couleur doit contenir au moins 3 caractères'),
  body('ownerId').isUUID().withMessage('ID propriétaire invalide')
];

// Créer un véhicule
router.post('/', authenticateToken, vehicleValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const {
      ownerId, make, model, year, licensePlate, color,
      chassisNumber, engineNumber, insuranceNumber, insuranceExpiry, technicalControlExpiry
    } = req.body;

    // Vérifier si la plaque existe déjà
    const existingVehicle = await db.query('SELECT id FROM vehicles WHERE license_plate = ?', [licensePlate]);
    if (existingVehicle.length > 0) {
      return res.status(409).json({
        error: 'Plaque déjà enregistrée',
        message: 'Un véhicule avec cette plaque d\'immatriculation existe déjà'
      });
    }

    // Récupérer le nom du propriétaire
    const owner = await db.query('SELECT first_name, last_name FROM citizens WHERE id = ?', [ownerId]);
    if (!owner.length) {
      return res.status(404).json({
        error: 'Propriétaire non trouvé',
        message: 'Aucun citoyen trouvé avec cet ID'
      });
    }

    const ownerName = `${owner[0].first_name} ${owner[0].last_name}`;
    const vehicleId = uuidv4();

    await db.run(
      `INSERT INTO vehicles (
        id, owner_id, owner_name, make, model, year, license_plate, color,
        chassis_number, engine_number, insurance_number, insurance_expiry, technical_control_expiry
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        vehicleId, ownerId, ownerName, make, model, year, licensePlate, color,
        chassisNumber || null, engineNumber || null, insuranceNumber || null,
        insuranceExpiry || null, technicalControlExpiry || null
      ]
    );

    const vehicle = await db.query('SELECT * FROM vehicles WHERE id = ?', [vehicleId]);

    res.status(201).json({
      message: 'Véhicule enregistré avec succès',
      vehicle: vehicle[0]
    });

  } catch (error) {
    console.error('Erreur création véhicule:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible d\'enregistrer le véhicule'
    });
  }
});

// Obtenir tous les véhicules
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { search, ownerId, limit = 50, offset = 0 } = req.query;
    
    let query = 'SELECT * FROM vehicles WHERE is_active = 1';
    let params = [];

    // Si c'est un citoyen, ne montrer que ses véhicules
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND owner_id = ?';
        params.push(citizen[0].id);
      }
    }

    if (search) {
      query += ' AND (license_plate LIKE ? OR make LIKE ? OR model LIKE ? OR owner_name LIKE ?)';
      const searchTerm = `%${search}%`;
      params.push(searchTerm, searchTerm, searchTerm, searchTerm);
    }

    if (ownerId) {
      query += ' AND owner_id = ?';
      params.push(ownerId);
    }

    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const vehicles = await db.query(query, params);

    res.json({ vehicles });

  } catch (error) {
    console.error('Erreur récupération véhicules:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les véhicules'
    });
  }
});

// Rechercher un véhicule par plaque
router.get('/search/:plate', authenticateToken, authorizeRoles('admin', 'police'), async (req, res) => {
  try {
    const { plate } = req.params;

    const vehicles = await db.query(
      'SELECT * FROM vehicles WHERE license_plate LIKE ? AND is_active = 1 LIMIT 10',
      [`%${plate}%`]
    );

    res.json({ vehicles });

  } catch (error) {
    console.error('Erreur recherche véhicule:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de rechercher le véhicule'
    });
  }
});

// Obtenir un véhicule par ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;

    let query = 'SELECT * FROM vehicles WHERE id = ?';
    let params = [id];

    // Si c'est un citoyen, vérifier qu'il possède le véhicule
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        query += ' AND owner_id = ?';
        params.push(citizen[0].id);
      }
    }

    const vehicles = await db.query(query, params);
    
    if (!vehicles.length) {
      return res.status(404).json({
        error: 'Véhicule non trouvé',
        message: 'Aucun véhicule trouvé avec cet ID'
      });
    }

    res.json({ vehicle: vehicles[0] });

  } catch (error) {
    console.error('Erreur récupération véhicule:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer le véhicule'
    });
  }
});

// Mettre à jour un véhicule
router.put('/:id', authenticateToken, vehicleValidation, logActivity, async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({
        error: 'Données invalides',
        details: errors.array()
      });
    }

    const { id } = req.params;
    const {
      make, model, year, licensePlate, color,
      chassisNumber, engineNumber, insuranceNumber, insuranceExpiry, technicalControlExpiry
    } = req.body;

    // Vérifier les permissions pour les citoyens
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        const vehicle = await db.query('SELECT id FROM vehicles WHERE id = ? AND owner_id = ?', [id, citizen[0].id]);
        if (!vehicle.length) {
          return res.status(403).json({
            error: 'Accès refusé',
            message: 'Vous ne pouvez modifier que vos propres véhicules'
          });
        }
      }
    }

    // Vérifier si la nouvelle plaque existe déjà (sauf pour ce véhicule)
    const existingVehicle = await db.query('SELECT id FROM vehicles WHERE license_plate = ? AND id != ?', [licensePlate, id]);
    if (existingVehicle.length > 0) {
      return res.status(409).json({
        error: 'Plaque déjà utilisée',
        message: 'Un autre véhicule utilise déjà cette plaque d\'immatriculation'
      });
    }

    const result = await db.run(
      `UPDATE vehicles SET 
        make = ?, model = ?, year = ?, license_plate = ?, color = ?,
        chassis_number = ?, engine_number = ?, insurance_number = ?,
        insurance_expiry = ?, technical_control_expiry = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [make, model, year, licensePlate, color, chassisNumber, engineNumber, insuranceNumber, insuranceExpiry, technicalControlExpiry, id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Véhicule non trouvé',
        message: 'Aucun véhicule trouvé avec cet ID'
      });
    }

    const updatedVehicle = await db.query('SELECT * FROM vehicles WHERE id = ?', [id]);

    res.json({
      message: 'Véhicule mis à jour avec succès',
      vehicle: updatedVehicle[0]
    });

  } catch (error) {
    console.error('Erreur mise à jour véhicule:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de mettre à jour le véhicule'
    });
  }
});

// Supprimer un véhicule
router.delete('/:id', authenticateToken, logActivity, async (req, res) => {
  try {
    const { id } = req.params;

    // Vérifier les permissions pour les citoyens
    if (req.user.role === 'citizen') {
      const citizen = await db.query('SELECT id FROM citizens WHERE user_id = ?', [req.user.id]);
      if (citizen.length) {
        const vehicle = await db.query('SELECT id FROM vehicles WHERE id = ? AND owner_id = ?', [id, citizen[0].id]);
        if (!vehicle.length) {
          return res.status(403).json({
            error: 'Accès refusé',
            message: 'Vous ne pouvez supprimer que vos propres véhicules'
          });
        }
      }
    }

    const result = await db.run(
      'UPDATE vehicles SET is_active = 0, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [id]
    );

    if (result.changes === 0) {
      return res.status(404).json({
        error: 'Véhicule non trouvé',
        message: 'Aucun véhicule trouvé avec cet ID'
      });
    }

    res.json({
      message: 'Véhicule supprimé avec succès'
    });

  } catch (error) {
    console.error('Erreur suppression véhicule:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de supprimer le véhicule'
    });
  }
});

// Obtenir les véhicules avec documents expirés
router.get('/alerts/expired', authenticateToken, authorizeRoles('admin', 'police'), async (req, res) => {
  try {
    const vehicles = await db.query(
      `SELECT * FROM vehicles 
       WHERE is_active = 1 
       AND (insurance_expiry < date('now') OR technical_control_expiry < date('now'))
       ORDER BY insurance_expiry ASC, technical_control_expiry ASC`
    );

    res.json({ vehicles });

  } catch (error) {
    console.error('Erreur véhicules expirés:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les véhicules avec documents expirés'
    });
  }
});

// Statistiques des véhicules
router.get('/stats/overview', authenticateToken, authorizeRoles('admin'), async (req, res) => {
  try {
    const stats = await Promise.all([
      db.query('SELECT COUNT(*) as total FROM vehicles WHERE is_active = 1'),
      db.query('SELECT COUNT(*) as expired_insurance FROM vehicles WHERE is_active = 1 AND insurance_expiry < date("now")'),
      db.query('SELECT COUNT(*) as expired_technical FROM vehicles WHERE is_active = 1 AND technical_control_expiry < date("now")'),
      db.query('SELECT COUNT(*) as recent FROM vehicles WHERE created_at >= date("now", "-30 days")')
    ]);

    res.json({
      total: stats[0][0].total,
      expiredInsurance: stats[1][0].expired_insurance,
      expiredTechnical: stats[2][0].expired_technical,
      recentRegistrations: stats[3][0].recent
    });

  } catch (error) {
    console.error('Erreur statistiques véhicules:', error);
    res.status(500).json({
      error: 'Erreur serveur',
      message: 'Impossible de récupérer les statistiques'
    });
  }
});

module.exports = router;